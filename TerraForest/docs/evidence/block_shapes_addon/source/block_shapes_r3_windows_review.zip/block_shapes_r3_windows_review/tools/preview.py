# SPDX-License-Identifier: 0BSD
"""Render actual catalogue triangles to a contact-sheet SVG, using stdlib only.
This is a mesh-data preview, NOT a screenshot or test of Godot rendering.
"""
from __future__ import annotations
import html
import json
import math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def dot(a,b):return sum(x*y for x,y in zip(a,b))
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def unit(a):return tuple(x/math.sqrt(dot(a,a)) for x in a)

def main():
    data=json.loads((ROOT/'addons/block_shapes/catalogue.json').read_text())
    by_id={s['id']:s for s in data['shapes']}
    desired=[
        'cube.full','slab.1of8.edge','slab.4of8.center','beam.0.25.center','beam.0.25.corner','block.h0.5.w0.75',
        'ramp.h1.w1','ramp.h0.5.w1','ramp.h0.25.w1','ramp.h1.w0.5','ramp.segment.4.2','ramp.segment.4.4',
        'stair.2.h1.w1','stair.4.h1.w1','stair.8.h1.w1','stair.4.h0.5.w1','stair.6.h1.w0.5','stair.3.h1.w1',
        'corner.outer.h1','corner.inner.h1','pyramid.h1','frustum.h1.top0.5','ridge.h0.5.w1','panel.r0.75.t0.125.w1',
        'window.t0.125.d1','door.t0.125.d0.5','arch.door.t0.125.d0.5','arch.t0.125.d0.5.h0.5','arch.t0.125.d0.5.h1','curve.quarter.t0.125.d0.5',
        'column.r0.5.n8','column.r0.25.n16','tube.r0.5.t0.125','cross.t0.125.d0.5','corner.trim.t0.125.d0.5','curve.solid.d0.5'
    ]
    chosen=[]
    for key in desired:
        if key in by_id:chosen.append(by_id[key])
        else:
            raise ValueError("Preview shape not found: " + key)
    columns=6;tw=202;th=184;width=columns*tw+40;header=124;height=header+6*th+50
    out=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
         '<metadata>SPDX-License-Identifier: CC0-1.0\nRendered from catalogue data using tools/preview.py.</metadata>',
         f'<rect width="{width}" height="{height}" fill="#151c24"/>',
         '<g font-family="DejaVu Sans, sans-serif">',
         '<text x="32" y="43" fill="#f3f5f7" font-size="28" font-weight="bold">BLOCK SHAPES / r2</text>',
         '<text x="32" y="73" fill="#c0cbd5" font-size="16">36 examples from 224 stored meshes · 18 families · CC0 geometry</text>',
         '<text x="32" y="99" fill="#8898a8" font-size="13">Actual generated triangle meshes. This is not a Godot screenshot or an engine-runtime validation.</text>']
    view=unit((4,3,5));right=unit((view[2],0,-view[0]));up=unit(cross(view,right));light=unit((-2,5,4))
    for i,shape in enumerate(chosen):
        x=20+(i%columns)*tw;y=header+(i//columns)*th
        out.append(f'<rect x="{x+4}" y="{y+4}" width="{tw-8}" height="{th-8}" rx="8" fill="#202a35"/>')
        cx=x+tw/2;cy=y+74;scale=83
        faces=[]
        for indices in shape['triangles']:
            verts=[sub(shape['vertices'][j],(.5,.5,.5)) for j in indices]
            n=unit(cross(sub(verts[1],verts[0]),sub(verts[2],verts[0])))
            if dot(n,view)<=1e-7:continue
            depth=sum(dot(p,view) for p in verts)/3
            shade=max(0,min(1,.4+.6*max(0,dot(n,light))))
            color='#{:02x}{:02x}{:02x}'.format(int(187*shade),int(203*shade),int(217*shade))
            points=' '.join(f'{cx+dot(p,right)*scale:.2f},{cy-dot(p,up)*scale:.2f}' for p in verts)
            faces.append((depth,f'<polygon points="{points}" fill="{color}" stroke="{color}" stroke-width="0.6"/>'))
        out.extend(f for _,f in sorted(faces))
        label=html.escape(shape['family'])
        out.append(f'<text x="{x+12}" y="{y+139}" fill="#e3ebf2" font-size="12" font-weight="bold">{label}</text>')
        out.append(f'<text x="{x+12}" y="{y+156}" fill="#aebccc" font-size="10">{html.escape(shape["id"])}</text>')
        out.append(f'<text x="{x+12}" y="{y+170}" fill="#8294a5" font-size="10">{len(shape["triangles"])} triangles</text>')
    out += [f'<text x="32" y="{height-20}" fill="#9fafbf" font-size="13">Code: 0BSD · Geometry: CC0 · See ORIGIN.md for the scope and limits of origin checks.</text>','</g></svg>']
    (ROOT/'docs/shapes.preview.svg').write_text('\n'.join(out),encoding='utf-8',newline='\n')
    print(ROOT/'docs/shapes.preview.svg')

if __name__=='__main__':main()
