# SPDX-License-Identifier: 0BSD
"""Generate the catalogue and derived reference documents; stdlib only."""
from __future__ import annotations
import collections
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ADDON = ROOT / 'addons' / 'block_shapes'

def main() -> None:
    spec = importlib.util.spec_from_file_location('block_shapes_builder', ADDON / 'build.py')
    build = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(build)
    recipes, raw = build.load_spec(ADDON / 'recipes.json')
    data = build.build_catalogue(recipes, raw)
    (ADDON / 'catalogue.json').write_bytes(build.canonical_json(data))
    counts = dict(sorted(collections.Counter(s['family'] for s in data['shapes']).items()))
    summary = {'mesh_entries': len(data['shapes']), 'same_pose_aliases': len(data['aliases']),
               'rotations': len(data['rotations']), 'families': counts,
               'minimum_triangles': min(len(s['triangles']) for s in data['shapes']),
               'maximum_triangles': max(len(s['triangles']) for s in data['shapes']),
               'recipe_source_sha256': data['recipe_source_sha256']}
    docs = ROOT / 'docs'
    docs.mkdir(exist_ok=True)
    (docs / 'catalogue.summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8', newline='\n')
    lines = ['<!-- SPDX-License-Identifier: CC0-1.0 -->', '# Block Shapes r2 catalogue', '',
             '224 stored meshes in 18 families; 3 additional exact-pose ID aliases. Counts do not claim uniqueness modulo rotation.', '',
             'Indices 0–217 preserve r1 catalogue order. Six formerly incorrect rotated aliases are now explicit meshes at indices 218–223.', '',
             'Each entry below has a complete numerical recipe in `addons/block_shapes/recipes.json`.', '',
             '| Index | ID | Family | Operation | Triangles |', '| --- | --- | --- | --- | --- |']
    for i, shape in enumerate(data['shapes']):
        lines.append(f'| {i} | `{shape["id"]}` | {shape["family"]} | `{shape["operation"]}` | {len(shape["triangles"])} |')
    lines += ['', '## Verified aliases', '']
    for key, value in data['aliases'].items():
        lines.append(f'- `{key}` → `{value}`. Generation verifies identical oriented triangles in the same pose.')
    (docs / 'CATALOGUE.md').write_text('\n'.join(lines)+'\n', encoding='utf-8', newline='\n')
    print(json.dumps(summary, indent=2))

if __name__ == '__main__':
    main()
