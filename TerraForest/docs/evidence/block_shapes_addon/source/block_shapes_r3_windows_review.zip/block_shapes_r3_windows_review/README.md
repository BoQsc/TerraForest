<!-- SPDX-License-Identifier: CC0-1.0 -->
# Block Shapes r3 — 0BSD software + CC0 geometry

This distribution contains 224 stored mathematical shape meshes in 18 families,
24 placement orientations, the Godot construction addon, GridMap integration,
a demonstration scene and the complete source/build inputs. Code is **0BSD**;
recipes, geometry and project content are **CC0-1.0**. See `LICENSE.md`.

## Status

This Windows review copy fixes platform-dependent line endings in the generated
reference documents. Godot 4.7.2 Windows import, runtime, demo, export and isolated
PCK checks have now run. Geometry and runtime remain unchanged. This is still
**not a production-qualified TerraForest world backend or an approved house kit**.
`STATUS.json` and `docs/VALIDATION.md` distinguish the measured scope explicitly.

TerraForest's construction contract requires separate grid blocks for every
architectural assembly. The full arch, door-frame and window-frame catalogue
entries are upstream references, **not accepted construction blocks**. Use
quarter-curves, trims and straight segments to make 2-, 4-, 6-, 8-block or larger
assemblies, with independent removal and storage. The external TerraForest
review demonstrates this separation; this archive does not integrate those
pieces into TerraForest's native renderer, damage system, inventory or saves.

r3 adds enforceable licence/dependency checks and a non-success result when
required engine tests cannot run. It does not pretend that rewording notices
or adding hashes establishes independent legal clearance. Core shape/runtime
implementation is retained from r2, not silently rewritten or relabelled.

## Install

Import `project.godot` to run the demo. For an existing project, copy only
`addons/block_shapes`, replacing the previous directory rather than merging
stale files. Preserve your own edits first. Enable **Block Shapes** in Project
Settings > Plugins; its export hook includes the numeric runtime catalogue.
Without the plugin, explicitly include `addons/block_shapes/catalogue.json`
in the export preset's non-resource file filter.

Controls: F1 browse/build; WASD fly; Q/E down/up; Shift fast; R/T rotate;
left click place; right click remove; G gallery; H house; F5 save; F9 load;
Escape release mouse. The runtime/demo source is retained from r2.

## Validation

Python 3.10+ and its standard library only:

    python tools/check.py --source-only

The explicit source-only mode is not a complete-release pass. Full automated
checks require a local Godot 4 editor:

    python tools/check.py --godot "C:\path\to\Godot_console.exe"

On Windows the equivalent is:

    run.tests.bat --godot "C:\path\to\Godot_console.exe"

Without `--source-only`, the runner requires Godot via `--godot`, the `GODOT`
environment variable, or PATH. A missing engine returns exit status **2**, not
success. Source/engine test failures return **1**. Full engine checks are
configured for import, runtime assertions, demo boot, PCK export and execution
from the isolated exported pack. They run in a temporary copy rather than
altering the user's project. The Windows review executed those export checks.
A headless pass still does not replace visual/performance testing.

The standalone addon can check its own policy and reproduce all geometry:

    python addons/block_shapes/audit.py
    python addons/block_shapes/verify.py --rebuild

## Licence/dependency enforcement

The audit rejects conflicting or missing code/content SPDX headers, foreign
licence labels, altered standard legal texts, unapproved Python imports,
external/dynamic GDScript resource dependencies, linked SVG assets, and
unexpected binary file types. Inventory checks reject unrecorded files and
changed hashes. Negative tests demonstrate these rejections even when a
manifest hash has been refreshed. The audit is a static policy check, not a
security sandbox, licence recognizer for arbitrary copied code or legal opinion.

## Architecture boundary

This is a chunked construction-shape addon, not a completed streaming terrain
engine. Chunk meshing is synchronous. LOD, GPU meshing, streaming and exact
partial-boundary clipping are not implemented. The current face culling is
conservative. Do not infer 7DTD-scale performance from the shape count.

Geometry regeneration: `python tools/generate.py` then `python tools/preview.py`.
Deliberate maintainer edits must update `provenance/files.json` before
`python tools/make_manifest.py --write`. This records reviewed source changes;
it does not itself approve their origin or convert their rights.
