<!-- SPDX-License-Identifier: CC0-1.0 -->
# Changelog

## r3 — licence-policy and release-gate enforcement

### Windows review correction — 2026-10-25

The regenerated reference documents now explicitly use LF on every platform.
Windows CRLF conversion previously failed the byte-identical regeneration gate
before engine testing. Geometry, recipes, shape IDs and runtime are unchanged.
Godot 4.7.2 Windows import/runtime/export and isolated-PCK checks were executed
during TerraForest assessment. This does not qualify the synchronous GDScript
world implementation for TerraForest production, or approve any house redesign.

Added licence/dependency audit and 28 regression tests. Full validation now
returns non-success when Godot is missing. Core geometry/runtime are unchanged.
See `docs/REWORK.md`.

## Retained prior change record

# Changes

## r2 — 2026-10-25

Explicit recipe source and whitelist-based build path; complete dimensions and
per-shape recipe hashes; standalone addon includes its own builder and verifier.
Removed generated executable catalogue.gd; runtime reads numeric JSON and an
editor export hook includes it in exports.

Replaced approximate rotational deduplication with three explicit verified
same-pose aliases. Restored six wrongly oriented alias definitions as explicit
meshes. Preserved all 218 earlier canonical mesh IDs, indices and geometry;
224 stored meshes now exist in the same 18 families.

Added catalogue and save-input validation, deterministic save ordering,
refresh_all(), immediate retirement of stale chunk collision nodes, recipe
and negative inventory tests, an expanded unexecuted Godot smoke script, clear
per-file licence classification and retained incoming source identities.

This is continued project development, not a clean-room reset or legal clearance.

## r1.1

Supplied provenance revision: refined licence scope and integrity records;
runtime and geometry were unchanged. See incoming hashes in ORIGIN.json.

## r1

Supplied initial shape-generator and Godot source prototype. No independent
authorship/legal clearance or engine runtime validation was established.
