<!-- SPDX-License-Identifier: CC0-1.0 -->
# r3 validation — 2026-10-25

## Later Windows review

The TerraForest assessment executed Godot 4.7.2 import, runtime smoke (557080
assertions, zero failures), demo startup, export and the isolated-PCK equivalent.
The original all-in-one gate first stopped on Windows CRLF differences in the
generated reference documents; this review copy explicitly writes LF instead.
The original 224-entry geometry catalogue remains byte-identical. In the Windows
Python run, 75 tests were discovered: 74 passed and one platform-dependent case
was skipped. Original historical claims below describe the earlier environment.

A separate 4096-cube boundary-edit probe measured approximately 29-33 ms for the
addon synchronous rebuild versus 0.21-0.55 ms for TerraForest's native reference
on the same machine/headless engine. These are narrow CPU timings, not general
shape performance or FPS. Native integration, save compatibility, authoritative
concave queries and house-by-house human approval remain outstanding.

The TerraForest component review also renders 2-, 4-, 6- and 8-block assemblies
from quarter curves, straight slabs and corner trims at integer grid cells.
Removing one arch cell leaves its neighbors intact and clears only its collision;
the saved assembly restores all cells. This verifies standalone components, not
integration with TerraForest damage, placement, inventory or binary persistence.
Complete arch/frame catalogue entries remain upstream references and must not
be used as monolithic architectural elements in TerraForest. The review is not
approval of any house, its appearance, or the standalone rendering quality.

## Original r3 report: executed

75 Python tests passed: 47 retained geometry/recipe/inventory tests, 20 added
licence/dependency-policy tests and eight release-runner tests. The runner tests
use controlled mocked subprocess outcomes; they are NOT Godot execution.

The declared licence/dependency audit is run for the full project and standalone
addon. It checks file scopes, SPDX/header consistency, the reviewed standard
legal texts, AST imports, project-local GDScript resource loads, SVG external
asset references and the admitted source file types. Both file manifests and
byte-identical geometry/document regeneration are checked separately.

Negative cases include a MIT header underneath a 0BSD manifest, changed legal
text, an imported third-party Python package, an external Godot addon reference,
a binary labelled CC0, a contradictory JSON licence, and a zero-exit process
that emitted script errors or did not finish its test. Hashes alone do not
satisfy these checks.

## Original r3 report: not executed

Godot parsing, editor import, actual runtime/physics tests, PCK export/run,
rendering, visual inspection and performance measurements. No suitable Godot
executable was installed, and official binary acquisition attempts failed in
this environment. These results are NOT inferred from Python test success.

The full validation command therefore returns non-success (exit 2) when the
engine is absent. Only explicit `--source-only` mode can pass without Godot,
and its output says that complete-release status has not been granted.

## Scope

Core geometry and runtime are unchanged from r2. This revision completes new
licence-policy enforcement, not the unexecuted engine acceptance tests. Static
policy checks are not independent copyright clearance or a security sandbox.
Unsigned hashes identify content, not a real-world signing identity.

Full suite on a machine with a local Godot 4 editor:

    python tools/check.py --godot "C:\path\to\Godot_console.exe"

Source-only suite:

    python tools/check.py --source-only

The full runner works in a temporary project copy, exports a PCK using the
addon export hook, and configures an isolated-pack runtime test. That export
path is supplied for testing; its success has not been claimed here.
