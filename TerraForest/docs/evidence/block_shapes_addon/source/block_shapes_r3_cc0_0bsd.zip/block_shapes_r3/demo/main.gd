# SPDX-License-Identifier: 0BSD
extends Node3D
## Fly-camera construction sandbox; uses only built-in Godot APIs.

const World = preload("res://addons/block_shapes/world.gd")
var world = World.new()
var camera: Camera3D
var ghost: MeshInstance3D
var preview_mesh: MeshInstance3D
var ghost_material: StandardMaterial3D
var search: LineEdit
var families: OptionButton
var shape_list: ItemList
var status: Label
var selected_info: Label
var selected_index: int = 0
var orientation: int = 0
var hit_cell := Vector3i.ZERO
var place_cell := Vector3i.ZERO
var has_target: bool = false
var message: String = "F1: enter build mode. Select a shape in the list."
var _refresh_clock: float = 0.0

func _ready() -> void:
	world.name = "Construction"
	add_child(world)
	for color in [Color(0.38, 0.42, 0.46), Color(0.72, 0.68, 0.60), Color(0.34, 0.39, 0.43), Color(0.72, 0.77, 0.82)]:
		var material := StandardMaterial3D.new()
		material.albedo_color = color
		material.roughness = 0.9
		world.materials.append(material)
	var environment := WorldEnvironment.new()
	environment.environment = Environment.new()
	environment.environment.background_mode = Environment.BG_COLOR
	environment.environment.background_color = Color(0.11, 0.14, 0.18)
	environment.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.environment.ambient_light_color = Color(0.78, 0.84, 0.93)
	environment.environment.ambient_light_energy = 0.65
	add_child(environment)
	var sunlight := DirectionalLight3D.new()
	sunlight.rotation_degrees = Vector3(-48, -32, 0)
	sunlight.light_energy = 1.4
	sunlight.shadow_enabled = true
	add_child(sunlight)
	camera = Camera3D.new()
	camera.far = 240.0
	camera.current = true
	add_child(camera)
	_home_camera()
	ghost_material = StandardMaterial3D.new()
	ghost_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	ghost_material.albedo_color = Color(0.2, 0.85, 1.0, 0.35)
	ghost_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	ghost = MeshInstance3D.new()
	ghost.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	ghost.visible = false
	add_child(ghost)
	_populate()
	_make_ui()
	selected_index = world.library.find_shape("ramp.h1.w1")
	_update_selection()
	world.flush()

func _home_camera() -> void:
	camera.position = Vector3(17, 10, 21)
	camera.look_at(Vector3(8, 1.5, 7))

func _populate() -> void:
	# Building pad and a small house; these all use the same runtime chunk mesher.
	for x in range(20):
		for z in range(20):
			world.set_block(Vector3i(x, -1, z), "cube.full", 0, 0)
	for x in range(4, 12):
		for z in range(4, 11):
			if x != 4 and x != 11 and z != 4 and z != 10:
				continue
			for y in range(3):
				if z == 4 and x == 7 and y < 2:
					continue
				var id := "cube.full"
				if (z == 4 or z == 10) and (x == 5 or x == 9) and y == 1:
					id = "window.t0.125.d1"
				world.set_block(Vector3i(x, y, z), id, 0, 1)
	var positive_x: int = world.library.find_orientation(Basis(Vector3.UP, PI * 0.5))
	var negative_x: int = world.library.find_orientation(Basis(Vector3.UP, -PI * 0.5))
	for x in range(4, 12):
		var part: int = x - 3 if x < 8 else 12 - x
		var id := "ramp.h0.25.w1" if part == 1 else "ramp.segment.4.%s" % part
		for z in range(3, 12):
			world.set_block(Vector3i(x, 3, z), id, positive_x if x < 8 else negative_x, 2)
	# A gallery with one example of every catalogue item. G jumps here.
	for i in range(world.library.shapes.size()):
		var x: int = (i % 16) * 2
		var z: int = floori(float(i) / 16.0) * 2 + 27
		world.set_block(Vector3i(x, -1, z), "cube.full", 0, 0)
		world.set_block_index(Vector3i(x, 0, z), i, 0, 3)

func _make_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var panel := PanelContainer.new()
	layer.add_child(panel)
	panel.set_anchors_and_offsets_preset(Control.PRESET_LEFT_WIDE)
	panel.offset_left = 16
	panel.offset_top = 16
	panel.offset_right = 316
	panel.offset_bottom = -16
	var margin := MarginContainer.new()
	for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		margin.add_theme_constant_override(side, 12)
	panel.add_child(margin)
	var column := VBoxContainer.new()
	margin.add_child(column)
	var title := Label.new()
	title.text = "BLOCK SHAPES / r2"
	title.add_theme_font_size_override("font_size", 22)
	column.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "%s meshes · 24 orientations\n0BSD code · CC0 shape assets" % world.library.shapes.size()
	column.add_child(subtitle)
	search = LineEdit.new()
	search.placeholder_text = "Search shape name or ID…"
	search.text_changed.connect(_filter_shapes)
	column.add_child(search)
	families = OptionButton.new()
	families.add_item("All families")
	var names: Array = []
	for shape in world.library.shapes:
		if not names.has(shape["family"]):
			names.append(shape["family"])
	names.sort()
	for family in names:
		families.add_item(family)
	families.item_selected.connect(func(_index: int): _filter_shapes())
	column.add_child(families)
	var preview := SubViewportContainer.new()
	preview.custom_minimum_size = Vector2(270, 160)
	preview.stretch = true
	column.add_child(preview)
	var viewport := SubViewport.new()
	viewport.size = Vector2i(270, 160)
	viewport.own_world_3d = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	preview.add_child(viewport)
	preview_mesh = MeshInstance3D.new()
	viewport.add_child(preview_mesh)
	var preview_camera := Camera3D.new()
	viewport.add_child(preview_camera)
	preview_camera.position = Vector3(1.8, 1.4, 2.0)
	preview_camera.look_at(Vector3.ZERO)
	preview_camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	preview_camera.size = 1.8
	preview_camera.current = true
	var preview_light := DirectionalLight3D.new()
	preview_light.rotation_degrees = Vector3(-35, -30, 0)
	preview_light.light_energy = 1.7
	viewport.add_child(preview_light)
	shape_list = ItemList.new()
	shape_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	shape_list.custom_minimum_size.y = 140
	shape_list.item_selected.connect(_select_item)
	column.add_child(shape_list)
	selected_info = Label.new()
	selected_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(selected_info)
	var instructions := Label.new()
	instructions.text = "F1: browse / build\nWASD: fly · Q/E: down/up · Shift: fast\nLeft click: place · Right click: remove\nR: yaw · T: tip · G: gallery · H: house\nF5: save world · F9: load world\nEsc: release mouse"
	instructions.add_theme_font_size_override("font_size", 13)
	column.add_child(instructions)
	status = Label.new()
	status.position = Vector2(336, 16)
	status.add_theme_font_size_override("font_size", 15)
	layer.add_child(status)
	var crosshair := Label.new()
	crosshair.text = "+"
	crosshair.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(crosshair)
	crosshair.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_filter_shapes()

func _filter_shapes(_text: String = "") -> void:
	shape_list.clear()
	var term := search.text.to_lower()
	var family := families.get_item_text(families.selected)
	for i in range(world.library.shapes.size()):
		var shape: Dictionary = world.library.shapes[i]
		if families.selected > 0 and shape["family"] != family:
			continue
		if not term.is_empty() and not (String(shape["label"]) + " " + String(shape["id"])).to_lower().contains(term):
			continue
		var row := shape_list.add_item(shape["label"])
		shape_list.set_item_metadata(row, i)
		if i == selected_index:
			shape_list.select(row)

func _select_item(row: int) -> void:
	selected_index = int(shape_list.get_item_metadata(row))
	_update_selection()

func _update_selection() -> void:
	ghost.mesh = world.library.create_mesh(selected_index, orientation, ghost_material)
	# Keep the preview object centered at the origin during rotation.
	preview_mesh.mesh = world.library.create_mesh(selected_index, orientation)
	preview_mesh.position = -Vector3.ONE * 0.5
	preview_mesh.rotation = Vector3.ZERO
	var shape: Dictionary = world.library.shapes[selected_index]
	selected_info.text = "%s\n%s triangles · orientation %s/24" % [shape["id"], shape["triangles"].size(), orientation + 1]

func _process(delta: float) -> void:
	if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		var movement := Vector3.ZERO
		if Input.is_physical_key_pressed(KEY_W): movement -= camera.global_basis.z
		if Input.is_physical_key_pressed(KEY_S): movement += camera.global_basis.z
		if Input.is_physical_key_pressed(KEY_A): movement -= camera.global_basis.x
		if Input.is_physical_key_pressed(KEY_D): movement += camera.global_basis.x
		if Input.is_physical_key_pressed(KEY_Q): movement -= Vector3.UP
		if Input.is_physical_key_pressed(KEY_E): movement += Vector3.UP
		var speed := 18.0 if Input.is_physical_key_pressed(KEY_SHIFT) else 7.0
		camera.position += movement.normalized() * delta * speed
	_refresh_clock += delta
	if _refresh_clock >= 0.2:
		_refresh_clock = 0.0
		var statistics: Dictionary = world.statistics()
		status.text = "%s\n%s blocks · %s chunks · %s visible triangles\nSparse prototype / no streaming or LOD" % [message, statistics["blocks"], statistics["chunks"], statistics["triangles"]]

func _physics_process(_delta: float) -> void:
	has_target = false
	ghost.visible = false
	if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		return
	var query := PhysicsRayQueryParameters3D.create(camera.global_position, camera.global_position - camera.global_basis.z * 40.0)
	var result := get_world_3d().direct_space_state.intersect_ray(query)
	if result.is_empty():
		return
	var normal: Vector3 = result["normal"]
	var inside: Vector3 = world.to_local(result["position"] - normal * 0.001) / world.cell_size
	hit_cell = Vector3i(floori(inside.x), floori(inside.y), floori(inside.z))
	var local_normal: Vector3 = world.global_basis.inverse() * normal
	var side: int = world.library.side_from_direction(local_normal)
	place_cell = hit_cell + world.library.DIRECTIONS[side]
	has_target = true
	ghost.visible = true
	ghost.position = world.to_global(Vector3(place_cell) * world.cell_size)
	ghost.scale = Vector3.ONE * world.cell_size

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_F1:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED else Input.MOUSE_MODE_CAPTURED
			message = "Build mode: aim at a surface. R/T rotate." if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED else "Browse mode: choose a shape, then F1."
		elif event.keycode == KEY_ESCAPE:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		elif event.keycode == KEY_F5:
			message = "Saved to user://block_shapes.world.json" if world.save_world("user://block_shapes.world.json") else "Save failed."
		elif event.keycode == KEY_F9:
			message = "Loaded saved world." if world.load_world("user://block_shapes.world.json") else "No valid saved world found."
		elif event.keycode == KEY_G:
			camera.position = Vector3(16, 18, 65)
			camera.look_at(Vector3(15, 0, 39))
		elif event.keycode == KEY_H:
			_home_camera()
		elif Input.mouse_mode == Input.MOUSE_MODE_CAPTURED and (event.keycode == KEY_R or event.keycode == KEY_T):
			var axis := Vector3.UP if event.keycode == KEY_R else Vector3.RIGHT
			orientation = world.library.find_orientation(Basis(axis, PI * 0.5) * world.library.rotations[orientation])
			_update_selection()
	if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		return
	if event is InputEventMouseMotion:
		camera.rotation.y -= event.relative.x * 0.0025
		camera.rotation.x = clampf(camera.rotation.x - event.relative.y * 0.0025, -1.5, 1.5)
	elif event is InputEventMouseButton and event.pressed and has_target:
		if event.button_index == MOUSE_BUTTON_LEFT and not world.has_block(place_cell):
			world.set_block_index(place_cell, selected_index, orientation, 3)
		elif event.button_index == MOUSE_BUTTON_RIGHT:
			world.remove_block(hit_cell)
