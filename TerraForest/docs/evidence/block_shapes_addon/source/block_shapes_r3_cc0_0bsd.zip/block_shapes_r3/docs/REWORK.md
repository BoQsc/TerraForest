<!-- SPDX-License-Identifier: CC0-1.0 -->
# r3 changes

The mathematical generator, recipes, numeric catalogue and core GDScript files
are retained from r2 without changing the 224 shape meshes or their IDs.

- Added a standalone licence/dependency audit with standard legal-text hashes,
  SPDX/content consistency checks, standard-library Python import checking,
  project-local GDScript dependency inspection and source-only asset policy.
- Added 20 policy tests, including negative cases where hashes alone would not
  catch a refreshed but conflicting licence or external import.
- Added eight test-runner tests. Missing Godot, engine errors despite exit 0,
  and missing runtime-success markers must not produce successful validation.
- Reworked the full runner to require actual engine execution unless the user
  explicitly selects source-only mode. Extended its configured checks to PCK
  export and isolated-pack execution. Engine checks remain unexecuted here.
- Made the actual release licence split prominent and preserved ancestry.
- Removed sentence punctuation from the SVG SPDX token so the generated
  metadata has an unambiguous licence identifier; rendered geometry unchanged.

This revision does not claim new runtime features, production readiness or
legal clearance. These checks are protections against later accidental drift,
not evidence that a licence header can cure unauthorized source copying.
