<!-- SPDX-License-Identifier: CC0-1.0 -->
# r3 validation — 2026-10-25

## Executed

75 Python tests passed: 47 retained geometry/recipe/inventory tests, 20 added
licence/dependency-policy tests and eight release-runner tests. The runner tests
use controlled mocked subprocess outcomes; they are NOT Godot execution.

The declared licence/dependency audit is run for the full project and standalone
addon. It checks file scopes, SPDX/header consistency, the reviewed standard
legal texts, AST imports, project-local GDScript resource loads, SVG external
asset references and the admitted source file types. Both file manifests and
byte-identical geometry/document regeneration are checked separately.

Negative cases include a MIT header underneath a 0BSD manifest, changed legal
text, an imported third-party Python package, an external Godot addon reference,
a binary labelled CC0, a contradictory JSON licence, and a zero-exit process
that emitted script errors or did not finish its test. Hashes alone do not
satisfy these checks.

## Not executed

Godot parsing, editor import, actual runtime/physics tests, PCK export/run,
rendering, visual inspection and performance measurements. No suitable Godot
executable was installed, and official binary acquisition attempts failed in
this environment. These results are NOT inferred from Python test success.

The full validation command therefore returns non-success (exit 2) when the
engine is absent. Only explicit `--source-only` mode can pass without Godot,
and its output says that complete-release status has not been granted.

## Scope

Core geometry and runtime are unchanged from r2. This revision completes new
licence-policy enforcement, not the unexecuted engine acceptance tests. Static
policy checks are not independent copyright clearance or a security sandbox.
Unsigned hashes identify content, not a real-world signing identity.

Full suite on a machine with a local Godot 4 editor:

    python tools/check.py --godot "C:\path\to\Godot_console.exe"

Source-only suite:

    python tools/check.py --source-only

The full runner works in a temporary project copy, exports a PCK using the
addon export hook, and configures an isolated-pack runtime test. That export
path is supplied for testing; its success has not been claimed here.
