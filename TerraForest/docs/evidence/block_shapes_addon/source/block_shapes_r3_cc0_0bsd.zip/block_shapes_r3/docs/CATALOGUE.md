<!-- SPDX-License-Identifier: CC0-1.0 -->
# Block Shapes r2 catalogue

224 stored meshes in 18 families; 3 additional exact-pose ID aliases. Counts do not claim uniqueness modulo rotation.

Indices 0–217 preserve r1 catalogue order. Six formerly incorrect rotated aliases are now explicit meshes at indices 218–223.

Each entry below has a complete numerical recipe in `addons/block_shapes/recipes.json`.

| Index | ID | Family | Operation | Triangles |
| --- | --- | --- | --- | --- |
| 0 | `cube.full` | Cuboids | `cuboid` | 12 |
| 1 | `slab.1of8.edge` | Cuboids | `cuboid` | 12 |
| 2 | `slab.1of8.center` | Cuboids | `cuboid` | 12 |
| 3 | `slab.2of8.edge` | Cuboids | `cuboid` | 12 |
| 4 | `slab.2of8.center` | Cuboids | `cuboid` | 12 |
| 5 | `slab.3of8.edge` | Cuboids | `cuboid` | 12 |
| 6 | `slab.3of8.center` | Cuboids | `cuboid` | 12 |
| 7 | `slab.4of8.edge` | Cuboids | `cuboid` | 12 |
| 8 | `slab.4of8.center` | Cuboids | `cuboid` | 12 |
| 9 | `slab.5of8.edge` | Cuboids | `cuboid` | 12 |
| 10 | `slab.5of8.center` | Cuboids | `cuboid` | 12 |
| 11 | `slab.6of8.edge` | Cuboids | `cuboid` | 12 |
| 12 | `slab.6of8.center` | Cuboids | `cuboid` | 12 |
| 13 | `slab.7of8.edge` | Cuboids | `cuboid` | 12 |
| 14 | `slab.7of8.center` | Cuboids | `cuboid` | 12 |
| 15 | `beam.0.125.center` | Beams | `cuboid` | 12 |
| 16 | `beam.0.125.corner` | Beams | `cuboid` | 12 |
| 17 | `beam.0.25.center` | Beams | `cuboid` | 12 |
| 18 | `beam.0.25.corner` | Beams | `cuboid` | 12 |
| 19 | `beam.0.375.center` | Beams | `cuboid` | 12 |
| 20 | `beam.0.375.corner` | Beams | `cuboid` | 12 |
| 21 | `beam.0.5.center` | Beams | `cuboid` | 12 |
| 22 | `beam.0.5.corner` | Beams | `cuboid` | 12 |
| 23 | `beam.0.75.center` | Beams | `cuboid` | 12 |
| 24 | `beam.0.75.corner` | Beams | `cuboid` | 12 |
| 25 | `block.h0.25.w0.5` | Cuboids | `cuboid` | 12 |
| 26 | `block.h0.25.w0.75` | Cuboids | `cuboid` | 12 |
| 27 | `block.h0.5.w0.75` | Cuboids | `cuboid` | 12 |
| 28 | `ramp.h0.125.w0.25` | Ramps | `ramp` | 8 |
| 29 | `ramp.h0.125.w0.5` | Ramps | `ramp` | 8 |
| 30 | `ramp.h0.125.w1` | Ramps | `ramp` | 8 |
| 31 | `ramp.h0.25.w0.25` | Ramps | `ramp` | 8 |
| 32 | `ramp.h0.25.w0.5` | Ramps | `ramp` | 8 |
| 33 | `ramp.h0.25.w1` | Ramps | `ramp` | 8 |
| 34 | `ramp.h0.375.w0.25` | Ramps | `ramp` | 8 |
| 35 | `ramp.h0.375.w0.5` | Ramps | `ramp` | 8 |
| 36 | `ramp.h0.375.w1` | Ramps | `ramp` | 8 |
| 37 | `ramp.h0.5.w0.25` | Ramps | `ramp` | 8 |
| 38 | `ramp.h0.5.w0.5` | Ramps | `ramp` | 8 |
| 39 | `ramp.h0.5.w1` | Ramps | `ramp` | 8 |
| 40 | `ramp.h0.625.w0.25` | Ramps | `ramp` | 8 |
| 41 | `ramp.h0.625.w0.5` | Ramps | `ramp` | 8 |
| 42 | `ramp.h0.625.w1` | Ramps | `ramp` | 8 |
| 43 | `ramp.h0.75.w0.25` | Ramps | `ramp` | 8 |
| 44 | `ramp.h0.75.w0.5` | Ramps | `ramp` | 8 |
| 45 | `ramp.h0.75.w1` | Ramps | `ramp` | 8 |
| 46 | `ramp.h0.875.w0.25` | Ramps | `ramp` | 8 |
| 47 | `ramp.h0.875.w0.5` | Ramps | `ramp` | 8 |
| 48 | `ramp.h0.875.w1` | Ramps | `ramp` | 8 |
| 49 | `ramp.h1.w0.25` | Ramps | `ramp` | 8 |
| 50 | `ramp.h1.w0.5` | Ramps | `ramp` | 8 |
| 51 | `ramp.h1.w1` | Ramps | `ramp` | 8 |
| 52 | `ramp.segment.2.2` | Ramp segments | `ramp_segment` | 12 |
| 53 | `ramp.segment.3.1` | Ramp segments | `ramp_segment` | 8 |
| 54 | `ramp.segment.3.2` | Ramp segments | `ramp_segment` | 12 |
| 55 | `ramp.segment.3.3` | Ramp segments | `ramp_segment` | 12 |
| 56 | `ramp.segment.4.2` | Ramp segments | `ramp_segment` | 12 |
| 57 | `ramp.segment.4.3` | Ramp segments | `ramp_segment` | 12 |
| 58 | `ramp.segment.4.4` | Ramp segments | `ramp_segment` | 12 |
| 59 | `ramp.segment.8.2` | Ramp segments | `ramp_segment` | 12 |
| 60 | `ramp.segment.8.3` | Ramp segments | `ramp_segment` | 12 |
| 61 | `ramp.segment.8.4` | Ramp segments | `ramp_segment` | 12 |
| 62 | `ramp.segment.8.5` | Ramp segments | `ramp_segment` | 12 |
| 63 | `ramp.segment.8.6` | Ramp segments | `ramp_segment` | 12 |
| 64 | `ramp.segment.8.7` | Ramp segments | `ramp_segment` | 12 |
| 65 | `ramp.segment.8.8` | Ramp segments | `ramp_segment` | 12 |
| 66 | `stair.2.h0.5.w0.5` | Stairs | `stairs` | 20 |
| 67 | `stair.2.h0.5.w1` | Stairs | `stairs` | 20 |
| 68 | `stair.2.h1.w0.5` | Stairs | `stairs` | 20 |
| 69 | `stair.2.h1.w1` | Stairs | `stairs` | 20 |
| 70 | `stair.3.h0.5.w0.5` | Stairs | `stairs` | 28 |
| 71 | `stair.3.h0.5.w1` | Stairs | `stairs` | 28 |
| 72 | `stair.3.h1.w0.5` | Stairs | `stairs` | 28 |
| 73 | `stair.3.h1.w1` | Stairs | `stairs` | 28 |
| 74 | `stair.4.h0.5.w0.5` | Stairs | `stairs` | 36 |
| 75 | `stair.4.h0.5.w1` | Stairs | `stairs` | 36 |
| 76 | `stair.4.h1.w0.5` | Stairs | `stairs` | 36 |
| 77 | `stair.4.h1.w1` | Stairs | `stairs` | 36 |
| 78 | `stair.6.h0.5.w0.5` | Stairs | `stairs` | 52 |
| 79 | `stair.6.h0.5.w1` | Stairs | `stairs` | 52 |
| 80 | `stair.6.h1.w0.5` | Stairs | `stairs` | 52 |
| 81 | `stair.6.h1.w1` | Stairs | `stairs` | 52 |
| 82 | `stair.8.h0.5.w0.5` | Stairs | `stairs` | 68 |
| 83 | `stair.8.h0.5.w1` | Stairs | `stairs` | 68 |
| 84 | `stair.8.h1.w0.5` | Stairs | `stairs` | 68 |
| 85 | `stair.8.h1.w1` | Stairs | `stairs` | 68 |
| 86 | `corner.outer.h0.25` | Roof corners | `roof_corner` | 6 |
| 87 | `corner.inner.h0.25` | Roof corners | `roof_corner` | 10 |
| 88 | `pyramid.h0.25` | Pyramids | `pyramid` | 6 |
| 89 | `ridge.h0.25.w0.5` | Roof ridges | `ridge` | 8 |
| 90 | `ridge.h0.25.w1` | Roof ridges | `ridge` | 8 |
| 91 | `corner.outer.h0.5` | Roof corners | `roof_corner` | 6 |
| 92 | `corner.inner.h0.5` | Roof corners | `roof_corner` | 10 |
| 93 | `pyramid.h0.5` | Pyramids | `pyramid` | 6 |
| 94 | `ridge.h0.5.w0.5` | Roof ridges | `ridge` | 8 |
| 95 | `ridge.h0.5.w1` | Roof ridges | `ridge` | 8 |
| 96 | `corner.outer.h0.75` | Roof corners | `roof_corner` | 6 |
| 97 | `corner.inner.h0.75` | Roof corners | `roof_corner` | 10 |
| 98 | `pyramid.h0.75` | Pyramids | `pyramid` | 6 |
| 99 | `ridge.h0.75.w0.5` | Roof ridges | `ridge` | 8 |
| 100 | `ridge.h0.75.w1` | Roof ridges | `ridge` | 8 |
| 101 | `corner.outer.h1` | Roof corners | `roof_corner` | 6 |
| 102 | `corner.inner.h1` | Roof corners | `roof_corner` | 10 |
| 103 | `pyramid.h1` | Pyramids | `pyramid` | 6 |
| 104 | `ridge.h1.w0.5` | Roof ridges | `ridge` | 8 |
| 105 | `ridge.h1.w1` | Roof ridges | `ridge` | 8 |
| 106 | `frustum.h0.25.top0.25` | Pyramids | `pyramid` | 12 |
| 107 | `frustum.h0.25.top0.5` | Pyramids | `pyramid` | 12 |
| 108 | `frustum.h0.25.top0.75` | Pyramids | `pyramid` | 12 |
| 109 | `frustum.h0.5.top0.25` | Pyramids | `pyramid` | 12 |
| 110 | `frustum.h0.5.top0.5` | Pyramids | `pyramid` | 12 |
| 111 | `frustum.h0.5.top0.75` | Pyramids | `pyramid` | 12 |
| 112 | `frustum.h1.top0.25` | Pyramids | `pyramid` | 12 |
| 113 | `frustum.h1.top0.5` | Pyramids | `pyramid` | 12 |
| 114 | `frustum.h1.top0.75` | Pyramids | `pyramid` | 12 |
| 115 | `panel.r0.25.t0.0625.w0.5` | Roof panels | `panel` | 12 |
| 116 | `panel.r0.25.t0.0625.w1` | Roof panels | `panel` | 12 |
| 117 | `panel.r0.25.t0.125.w0.5` | Roof panels | `panel` | 12 |
| 118 | `panel.r0.25.t0.125.w1` | Roof panels | `panel` | 12 |
| 119 | `panel.r0.25.t0.25.w0.5` | Roof panels | `panel` | 12 |
| 120 | `panel.r0.25.t0.25.w1` | Roof panels | `panel` | 12 |
| 121 | `panel.r0.5.t0.0625.w0.5` | Roof panels | `panel` | 12 |
| 122 | `panel.r0.5.t0.0625.w1` | Roof panels | `panel` | 12 |
| 123 | `panel.r0.5.t0.125.w0.5` | Roof panels | `panel` | 12 |
| 124 | `panel.r0.5.t0.125.w1` | Roof panels | `panel` | 12 |
| 125 | `panel.r0.5.t0.25.w0.5` | Roof panels | `panel` | 12 |
| 126 | `panel.r0.5.t0.25.w1` | Roof panels | `panel` | 12 |
| 127 | `panel.r0.75.t0.0625.w0.5` | Roof panels | `panel` | 12 |
| 128 | `panel.r0.75.t0.0625.w1` | Roof panels | `panel` | 12 |
| 129 | `panel.r0.75.t0.125.w0.5` | Roof panels | `panel` | 12 |
| 130 | `panel.r0.75.t0.125.w1` | Roof panels | `panel` | 12 |
| 131 | `panel.r0.75.t0.25.w0.5` | Roof panels | `panel` | 12 |
| 132 | `panel.r0.75.t0.25.w1` | Roof panels | `panel` | 12 |
| 133 | `column.r0.125.n8` | Columns | `column` | 32 |
| 134 | `column.r0.125.n12` | Columns | `column` | 48 |
| 135 | `column.r0.125.n16` | Columns | `column` | 64 |
| 136 | `column.r0.25.n8` | Columns | `column` | 32 |
| 137 | `column.r0.25.n12` | Columns | `column` | 48 |
| 138 | `column.r0.25.n16` | Columns | `column` | 64 |
| 139 | `column.r0.5.n8` | Columns | `column` | 32 |
| 140 | `column.r0.5.n12` | Columns | `column` | 48 |
| 141 | `column.r0.5.n16` | Columns | `column` | 64 |
| 142 | `tube.r0.25.t0.0625` | Tubes | `column` | 128 |
| 143 | `tube.r0.25.t0.125` | Tubes | `column` | 128 |
| 144 | `tube.r0.5.t0.0625` | Tubes | `column` | 128 |
| 145 | `tube.r0.5.t0.125` | Tubes | `column` | 128 |
| 146 | `door.t0.0625.d0.125` | Door frames | `frame` | 44 |
| 147 | `window.t0.0625.d0.125` | Window frames | `frame` | 64 |
| 148 | `corner.trim.t0.0625.d0.125` | Trims | `trim` | 28 |
| 149 | `door.t0.0625.d0.5` | Door frames | `frame` | 44 |
| 150 | `window.t0.0625.d0.5` | Window frames | `frame` | 64 |
| 151 | `corner.trim.t0.0625.d0.5` | Trims | `trim` | 28 |
| 152 | `door.t0.0625.d1` | Door frames | `frame` | 44 |
| 153 | `window.t0.0625.d1` | Window frames | `frame` | 64 |
| 154 | `corner.trim.t0.0625.d1` | Trims | `trim` | 28 |
| 155 | `door.t0.125.d0.125` | Door frames | `frame` | 44 |
| 156 | `window.t0.125.d0.125` | Window frames | `frame` | 64 |
| 157 | `corner.trim.t0.125.d0.125` | Trims | `trim` | 28 |
| 158 | `door.t0.125.d0.5` | Door frames | `frame` | 44 |
| 159 | `window.t0.125.d0.5` | Window frames | `frame` | 64 |
| 160 | `corner.trim.t0.125.d0.5` | Trims | `trim` | 28 |
| 161 | `door.t0.125.d1` | Door frames | `frame` | 44 |
| 162 | `window.t0.125.d1` | Window frames | `frame` | 64 |
| 163 | `corner.trim.t0.125.d1` | Trims | `trim` | 28 |
| 164 | `door.t0.25.d0.125` | Door frames | `frame` | 44 |
| 165 | `window.t0.25.d0.125` | Window frames | `frame` | 64 |
| 166 | `corner.trim.t0.25.d0.125` | Trims | `trim` | 28 |
| 167 | `door.t0.25.d0.5` | Door frames | `frame` | 44 |
| 168 | `window.t0.25.d0.5` | Window frames | `frame` | 64 |
| 169 | `corner.trim.t0.25.d0.5` | Trims | `trim` | 28 |
| 170 | `door.t0.25.d1` | Door frames | `frame` | 44 |
| 171 | `window.t0.25.d1` | Window frames | `frame` | 64 |
| 172 | `corner.trim.t0.25.d1` | Trims | `trim` | 28 |
| 173 | `cross.t0.0625.d0.125` | Trims | `trim` | 44 |
| 174 | `cross.t0.0625.d0.5` | Trims | `trim` | 44 |
| 175 | `cross.t0.125.d0.125` | Trims | `trim` | 44 |
| 176 | `cross.t0.125.d0.5` | Trims | `trim` | 44 |
| 177 | `cross.t0.25.d0.125` | Trims | `trim` | 44 |
| 178 | `cross.t0.25.d0.5` | Trims | `trim` | 44 |
| 179 | `arch.t0.0625.d0.125.h0.5` | Arches | `arch` | 100 |
| 180 | `arch.t0.0625.d0.125.h1` | Arches | `arch` | 100 |
| 181 | `arch.t0.0625.d0.5.h0.5` | Arches | `arch` | 100 |
| 182 | `arch.t0.0625.d0.5.h1` | Arches | `arch` | 100 |
| 183 | `arch.t0.0625.d1.h0.5` | Arches | `arch` | 100 |
| 184 | `arch.t0.0625.d1.h1` | Arches | `arch` | 100 |
| 185 | `arch.t0.125.d0.125.h0.5` | Arches | `arch` | 100 |
| 186 | `arch.t0.125.d0.125.h1` | Arches | `arch` | 100 |
| 187 | `arch.t0.125.d0.5.h0.5` | Arches | `arch` | 100 |
| 188 | `arch.t0.125.d0.5.h1` | Arches | `arch` | 100 |
| 189 | `arch.t0.125.d1.h0.5` | Arches | `arch` | 100 |
| 190 | `arch.t0.125.d1.h1` | Arches | `arch` | 100 |
| 191 | `arch.t0.25.d0.125.h0.5` | Arches | `arch` | 100 |
| 192 | `arch.t0.25.d0.125.h1` | Arches | `arch` | 100 |
| 193 | `arch.t0.25.d0.5.h0.5` | Arches | `arch` | 100 |
| 194 | `arch.t0.25.d0.5.h1` | Arches | `arch` | 100 |
| 195 | `arch.t0.25.d1.h0.5` | Arches | `arch` | 100 |
| 196 | `arch.t0.25.d1.h1` | Arches | `arch` | 100 |
| 197 | `arch.door.t0.0625.d0.125` | Arched openings | `arched_opening` | 72 |
| 198 | `arch.door.t0.0625.d0.5` | Arched openings | `arched_opening` | 72 |
| 199 | `arch.door.t0.0625.d1` | Arched openings | `arched_opening` | 72 |
| 200 | `arch.door.t0.125.d0.125` | Arched openings | `arched_opening` | 72 |
| 201 | `arch.door.t0.125.d0.5` | Arched openings | `arched_opening` | 72 |
| 202 | `arch.door.t0.125.d1` | Arched openings | `arched_opening` | 72 |
| 203 | `arch.door.t0.25.d0.125` | Arched openings | `arched_opening` | 72 |
| 204 | `arch.door.t0.25.d0.5` | Arched openings | `arched_opening` | 72 |
| 205 | `arch.door.t0.25.d1` | Arched openings | `arched_opening` | 72 |
| 206 | `curve.quarter.t0.0625.d0.125` | Curved trims | `quarter_curve` | 68 |
| 207 | `curve.quarter.t0.0625.d0.5` | Curved trims | `quarter_curve` | 68 |
| 208 | `curve.quarter.t0.0625.d1` | Curved trims | `quarter_curve` | 68 |
| 209 | `curve.quarter.t0.125.d0.125` | Curved trims | `quarter_curve` | 68 |
| 210 | `curve.quarter.t0.125.d0.5` | Curved trims | `quarter_curve` | 68 |
| 211 | `curve.quarter.t0.125.d1` | Curved trims | `quarter_curve` | 68 |
| 212 | `curve.quarter.t0.25.d0.125` | Curved trims | `quarter_curve` | 68 |
| 213 | `curve.quarter.t0.25.d0.5` | Curved trims | `quarter_curve` | 68 |
| 214 | `curve.quarter.t0.25.d1` | Curved trims | `quarter_curve` | 68 |
| 215 | `curve.solid.d0.25` | Curved solids | `quarter_curve` | 36 |
| 216 | `curve.solid.d0.5` | Curved solids | `quarter_curve` | 36 |
| 217 | `curve.solid.d1` | Curved solids | `quarter_curve` | 36 |
| 218 | `block.h0.25.w0.25` | Cuboids | `cuboid` | 12 |
| 219 | `block.h0.5.w0.25` | Cuboids | `cuboid` | 12 |
| 220 | `block.h0.5.w0.5` | Cuboids | `cuboid` | 12 |
| 221 | `block.h0.75.w0.25` | Cuboids | `cuboid` | 12 |
| 222 | `block.h0.75.w0.5` | Cuboids | `cuboid` | 12 |
| 223 | `block.h0.75.w0.75` | Cuboids | `cuboid` | 12 |

## Verified aliases

- `ramp.segment.2.1` → `ramp.h0.5.w1`. Generation verifies identical oriented triangles in the same pose.
- `ramp.segment.4.1` → `ramp.h0.25.w1`. Generation verifies identical oriented triangles in the same pose.
- `ramp.segment.8.1` → `ramp.h0.125.w1`. Generation verifies identical oriented triangles in the same pose.
