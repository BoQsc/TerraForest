<!-- SPDX-License-Identifier: CC0-1.0 -->
# Numerical shape specification

The cell is the closed unit cube [0,1]^3, with Y up. Shapes are stored with
counter-clockwise outward triangle winding; the Godot adapter reverses the
index order for its clockwise front-face convention. All 24 orientations
are proper signed-permutation matrices, with identity first, applied about
the cell centre (0.5,0.5,0.5). Reflections are not orientations.

## Primitive operations

`cuboid`: axis-aligned origin plus positive size. Used for cubes, slabs, beams
and partial blocks. No unrecorded offsets or asset dimensions.

`ramp`: extrude the triangular profile (0,0),(1,0),(1,height) to the specified
width, centred across X. `ramp_segment`: extrude a linear height interval
[(part-1)/parts, part/parts]. The lower surface is at Y=0.

`stairs`: split a unit run into equal intervals. Step i has top height
(i+1)*height/steps. Extrude the resulting profile to the recorded centred width.

`roof_corner`: outer top is height*min(x,z); inner top is height*max(x,z).
Bottom is Y=0. `ridge`: extruded triangular profile (0,0),(1,0),(0.5,height).
`pyramid`: centred square top of the recorded side length at the recorded
height; a zero top length is an apex. `panel`: parallel linear profiles with
vertical separation equal to thickness (not normal-distance thickness).

`column`: a regular polygon with `segments` sides sampled from angle zero
around (0.5,0.5) in XZ, extruded from Y=0 to height. Positive inner radius
makes a tube. No external curved-surface mesh is read.

`frame`: union of axis-aligned jamb/lintel boxes; a window also has a bottom
bar. `trim`: union of a corner pair or centred crossing pair. Internal box
faces are removed on the induced coordinate grid.

`arch`: an outer half ellipse with horizontal radius 0.5 and vertical radius
height; the inner radii are proportionally reduced by thickness. Thus thickness
is a radial parameter, not a constant normal-offset thickness on an ellipse.
`arched_opening`: a unit square with an open bottom doorway, straight sides up
to Y=0.5 and a polygonal semicircular head of radius 0.5-thickness.

`quarter_curve`: a polygonal quarter circle centred at the profile origin;
solid includes the origin, trim includes a reversed inner arc. Extruded in Z
at the centred recorded depth. Every circular/elliptical resolution is
explicitly present as a segment count in recipes.json.

## Mesh construction and scope

Simple profiles are triangulated by testing convex ears and whether another
profile vertex occupies the candidate triangle, then extruded with cap and
side faces. Box unions are generated from sorted boundary coordinates and
occupied subcells, not runtime CSG. Vertices are rounded to eight decimal
places; degenerate triangles are omitted by the mesh helper. Shipped recipes
are checked for nondegeneracy, closed two-manifold edges, consistent winding,
positive volume and unit-cell bounds.

The builder allows only enumerated operations with fixed parameter schemas.
It does not accept arbitrary expressions, mesh vertices or imported assets.
Shape equivalence for the three ID aliases means identical oriented triangle
coordinates in the same pose. Geometrically equivalent surfaces with a
different triangulation are deliberately not automatically aliased.

Boundary triangles are tagged -X,+X,-Y,+Y,-Z,+Z or interior/sloping. The
full-boundary mask is based on unit face area in these validated non-overlapping
meshes. The runtime hides a boundary triangle only when an opaque neighbour
covers the whole opposing face. Partial-overlap clipping is not implemented.

This specification documents the actual inherited/adapted mathematical
construction; it does not assert that mathematical generation itself proves
historical independence or legal clearance.

API reference consulted: https://docs.godotengine.org/en/stable/classes/class_surfacetool.html
