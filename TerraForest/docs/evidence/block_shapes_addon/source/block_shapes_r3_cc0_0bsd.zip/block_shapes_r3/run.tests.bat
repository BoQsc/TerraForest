@echo off
rem SPDX-License-Identifier: 0BSD
setlocal
cd /d "%~dp0"
python tools\check.py %*
set RESULT=%ERRORLEVEL%
if not "%RESULT%"=="0" echo Validation failed or is blocked. Read the error above.
exit /b %RESULT%
