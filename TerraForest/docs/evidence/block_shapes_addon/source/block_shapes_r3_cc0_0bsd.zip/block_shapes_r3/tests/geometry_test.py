# SPDX-License-Identifier: 0BSD
"""Geometry/data tests (separate checks, not an independent legal audit); stdlib only. Does not execute Godot."""
from __future__ import annotations
import collections
import json
import math
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
DATA=json.loads((ROOT/'addons/block_shapes/catalogue.json').read_text(encoding='utf-8'))
SHAPES={s['id']:s for s in DATA['shapes']}

def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def cross(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def side_map(side,rotation):
    axis,positive=divmod(side,2)
    for new_axis in range(3):
        value=rotation[new_axis][axis]*(1 if positive else -1)
        if value:return 2*new_axis+int(value>0)
    raise AssertionError('Invalid rotation')

def prepare(shape,orientation):
    r=DATA['rotations'][orientation]
    mask=0
    for side in range(6):
        if shape['full_sides'] & (1<<side):mask|=1<<side_map(side,r)
    return ([side_map(s,r) if s>=0 else -1 for s in shape['sides']],mask)

DIRECTIONS=((-1,0,0),(1,0,0),(0,-1,0),(0,1,0),(0,0,-1),(0,0,1))

def visible_triangles(cells):
    cache={value:prepare(SHAPES[value[0]],value[1]) for value in set(cells.values())}
    count=0
    for position,value in cells.items():
        sides,_=cache[value]
        for side in sides:
            if side<0: count+=1;continue
            neighbor=tuple(a+b for a,b in zip(position,DIRECTIONS[side]))
            other=cells.get(neighbor)
            if other is None or not (cache[other][1] & (1<<(side^1))): count+=1
    return count

class GeometryTests(unittest.TestCase):
    def test_01_ids(self):
        ids=[s['id'] for s in DATA['shapes']]
        self.assertEqual(len(ids),len(set(ids)))
        self.assertGreaterEqual(len(ids),200)
        self.assertEqual(DATA['license'],'CC0-1.0')
    def test_02_finite_unit_vertices(self):
        for shape in DATA['shapes']:
            with self.subTest(shape=shape['id']):
                for v in shape['vertices']:
                    self.assertEqual(len(v),3)
                    self.assertTrue(all(math.isfinite(x) and -1e-7<=x<=1+1e-7 for x in v))
    def test_03_nondegenerate_triangles(self):
        for s in DATA['shapes']:
            with self.subTest(shape=s['id']):
                triangles=set()
                for a,b,c in s['triangles']:
                    self.assertEqual(len({a,b,c}),3)
                    self.assertTrue(all(0<=i<len(s['vertices']) for i in (a,b,c)))
                    n=cross(sub(s['vertices'][b],s['vertices'][a]),sub(s['vertices'][c],s['vertices'][a]))
                    self.assertGreater(dot(n,n),1e-16)
                    key=tuple(sorted((a,b,c)))
                    self.assertNotIn(key,triangles)
                    triangles.add(key)
    def test_04_closed_two_manifold_edges(self):
        for s in DATA['shapes']:
            with self.subTest(shape=s['id']):
                edges=collections.Counter()
                for a,b,c in s['triangles']:
                    for edge in ((a,b),(b,c),(c,a)):edges[tuple(sorted(edge))]+=1
                self.assertTrue(all(n==2 for n in edges.values()),repr({k:v for k,v in edges.items() if v!=2})[:400])
    def test_05_consistent_winding(self):
        for s in DATA['shapes']:
            with self.subTest(shape=s['id']):
                directed=collections.Counter()
                for a,b,c in s['triangles']:directed.update(((a,b),(b,c),(c,a)))
                self.assertTrue(all(directed[(b,a)]==n==1 for (a,b),n in directed.items()))
                volume=sum(dot(s['vertices'][a],cross(s['vertices'][b],s['vertices'][c]))/6 for a,b,c in s['triangles'])
                self.assertGreater(volume,0)
                self.assertLessEqual(volume,1+1e-6)
    def test_06_boundary_tags_and_full_faces(self):
        for s in DATA['shapes']:
            with self.subTest(shape=s['id']):
                self.assertEqual(len(s['sides']),len(s['triangles']))
                areas=[0.0]*6
                for (a,b,c),side in zip(s['triangles'],s['sides']):
                    if side<0:continue
                    axis,positive=divmod(side,2)
                    points=[s['vertices'][i] for i in (a,b,c)]
                    self.assertTrue(all(abs(p[axis]-positive)<1e-7 for p in points))
                    n=cross(sub(points[1],points[0]),sub(points[2],points[0]))
                    self.assertGreater(n[axis]*(1 if positive else -1),0)
                    areas[side]+=math.sqrt(dot(n,n))/2
                for side,area in enumerate(areas):
                    self.assertLessEqual(area,1+1e-6)
                    self.assertEqual(bool(s['full_sides']&(1<<side)),abs(area-1)<1e-6)
    def test_07_twenty_four_proper_rotations(self):
        rotations=DATA['rotations']
        self.assertEqual(len(rotations),24)
        self.assertEqual(rotations[0],[[1,0,0],[0,1,0],[0,0,1]])
        self.assertEqual(len({str(r) for r in rotations}),24)
        for r in rotations:
            self.assertEqual(dot(r[0],cross(r[1],r[2])),1)
            for i in range(3):
                for j in range(3):self.assertEqual(dot(r[i],r[j]),int(i==j))
    def test_08_all_rotations_all_shapes(self):
        for s in DATA['shapes']:
            for index,r in enumerate(DATA['rotations']):
                with self.subTest(shape=s['id'],rotation=index):
                    sides,mask=prepare(s,index)
                    self.assertEqual(len(sides),len(s['triangles']))
                    self.assertEqual(mask.bit_count(),s['full_sides'].bit_count())
                    for side in range(6):self.assertEqual(side_map(side^1,r),side_map(side,r)^1)
    def test_09_adjacent_cubes(self):
        self.assertEqual(visible_triangles({(0,0,0):('cube.full',0)}),12)
        for orientation in range(24):
            self.assertEqual(visible_triangles({(0,0,0):('cube.full',0),(1,0,0):('cube.full',orientation)}),20)
        # Same geometry across a chunk boundary and in negative coordinates.
        self.assertEqual(visible_triangles({(15,0,0):('cube.full',0),(16,0,0):('cube.full',0)}),20)
        self.assertEqual(visible_triangles({(-1,0,0):('cube.full',0),(0,0,0):('cube.full',0)}),20)
    def test_10_solid_chunk_surface(self):
        n=16
        cells={(x,y,z):('cube.full',0) for x in range(n) for y in range(n) for z in range(n)}
        self.assertEqual(visible_triangles(cells),6*n*n*2)
    def test_11_opening_not_false_occluder(self):
        s=SHAPES['window.t0.125.d1']
        self.assertFalse(s['full_sides']&(1<<4))
        self.assertFalse(s['full_sides']&(1<<5))
        # Cube face behind a window must remain, because the opening exposes it.
        self.assertEqual(prepare(s,0)[1]&((1<<4)|(1<<5)),0)
    def test_12_aliases(self):
        for alias,canonical in DATA['aliases'].items():
            self.assertNotIn(alias,SHAPES)
            self.assertIn(canonical,SHAPES)
        self.assertEqual(len(DATA['aliases']),len(DATA['deduplicated_candidates']))
    def test_13_plain_data_and_source_digest(self):
        import hashlib
        self.assertEqual(DATA['format'], 2)
        self.assertEqual(len(DATA['shapes']), 224)
        self.assertFalse((ROOT/'addons/block_shapes/catalogue.gd').exists())
        source = (ROOT/'addons/block_shapes/recipes.json').read_bytes()
        self.assertEqual(DATA['recipe_source_sha256'], hashlib.sha256(source).hexdigest())

if __name__=='__main__':
    unittest.main(verbosity=2)
