# SPDX-License-Identifier: 0BSD
"""Test explicit recipes, analytic volumes, lineage and hostile inputs; stdlib only."""
from __future__ import annotations
import ast
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
ADDON = ROOT/'addons/block_shapes'
module_spec = importlib.util.spec_from_file_location('recipe_builder', ADDON/'build.py')
build = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(build)
SPEC, RAW = build.load_spec(ADDON/'recipes.json')
DATA = json.loads((ADDON/'catalogue.json').read_text(encoding='utf-8'))
SHAPES = {s['id']:s for s in DATA['shapes']}


def expected_volume(recipe):
    p, op = recipe['parameters'], recipe['operation']
    if op == 'cuboid': return math.prod(p['size'])
    if op in ('ramp', 'ridge'): return p['height']*p['width']/2
    if op == 'ramp_segment': return (2*p['part']-1)/(2*p['parts'])
    if op == 'stairs': return p['height']*p['width']*(p['steps']+1)/(2*p['steps'])
    if op == 'roof_corner': return p['height']*(2 if p['inner'] else 1)/3
    if op == 'pyramid': return p['height']*(1+p['top']+p['top']**2)/3
    if op == 'panel': return p['width']*p['thickness']
    if op == 'column': return p['segments']*math.sin(2*math.pi/p['segments'])*(p['radius']**2-p['inner']**2)*p['height']/2
    if op == 'frame':
        t=p['thickness']
        return p['depth']*((4*t-4*t*t) if p['kind']=='window' else (3*t-2*t*t))
    if op == 'trim': return p['depth']*(2*p['thickness']-p['thickness']**2)
    if op == 'arch':
        ri=0.5-p['thickness']
        return p['segments']*math.sin(math.pi/p['segments'])*p['height']*(0.5-2*ri*ri)*p['depth']/2
    if op == 'arched_opening':
        radius=0.5-p['thickness']
        return p['depth']*(1-radius-p['segments']*radius**2*math.sin(math.pi/p['segments'])/2)
    if op == 'quarter_curve':
        area=p['segments']*math.sin(math.pi/(2*p['segments']))/2
        return p['depth']*area*(1 if p['solid'] else 1-(1-p['thickness'])**2)
    raise AssertionError(op)


def mesh_volume(shape):
    return sum(build.dot(shape['vertices'][a], build.cross(shape['vertices'][b],shape['vertices'][c]))/6 for a,b,c in shape['triangles'])


class RecipeTests(unittest.TestCase):
    def test_01_catalogue_reproduces_exactly(self):
        self.assertEqual(build.canonical_json(build.build_catalogue(SPEC, RAW)), (ADDON/'catalogue.json').read_bytes())

    def test_02_every_shape_has_complete_recipe_hash(self):
        self.assertEqual(len(SPEC['shapes']),224)
        for recipe in SPEC['shapes']:
            self.assertEqual(set(recipe['parameters']),build.SCHEMAS[recipe['operation']])
            shape=SHAPES[recipe['id']]
            self.assertEqual(shape['parameters'],recipe['parameters'])
            self.assertEqual(shape['recipe_sha256'],hashlib.sha256(build.canonical_json(recipe)).hexdigest())

    def test_03_all_analytic_volumes(self):
        for recipe in SPEC['shapes']:
            with self.subTest(shape=recipe['id']):
                self.assertAlmostEqual(mesh_volume(SHAPES[recipe['id']]),expected_volume(recipe),delta=2e-7)

    def test_04_corrected_blocks_have_requested_axes(self):
        for recipe in SPEC['shapes']:
            if recipe['id'].startswith('block.'):
                points=SHAPES[recipe['id']]['vertices']
                extent=[max(v[i] for v in points)-min(v[i] for v in points) for i in range(3)]
                self.assertEqual(extent,recipe['parameters']['size'])
                self.assertNotIn(recipe['id'],DATA['aliases'])

    def test_05_only_exact_pose_aliases(self):
        self.assertEqual(len(SPEC['aliases']),3)
        recipes={r['id']:r for r in SPEC['shapes']}
        for alias in SPEC['aliases']:
            self.assertEqual(build.signature(build.mesh_from_recipe(alias['recipe'])),build.signature(build.mesh_from_recipe(recipes[alias['target']])))

    def test_06_original_218_ids_indices_and_geometry_preserved(self):
        fixture=json.loads((ROOT/'tests/r1.compatibility.json').read_text(encoding='utf-8'))
        for entry,shape in zip(fixture['entries'], DATA['shapes']):
            self.assertEqual(entry['id'],shape['id'])
            payload={k:shape[k] for k in ('vertices','triangles','sides','full_sides')}
            digest=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()
            self.assertEqual(entry['geometry_sha256'],digest,entry['id'])
        self.assertEqual(len(fixture['entries']),218)

    def test_07_signature_checks_faces_and_winding(self):
        m=build.mesh_from_recipe(SPEC['shapes'][0])
        original=build.signature(m)
        m.triangles[0]=list(reversed(m.triangles[0]))
        self.assertNotEqual(original,build.signature(m))

    def test_08_signature_does_not_ignore_position(self):
        first=build.mesh_from_recipe(next(r for r in SPEC['shapes'] if r['id']=='block.h0.5.w0.25'))
        second=build.mesh_from_recipe(next(r for r in SPEC['shapes'] if r['id']=='block.h0.25.w0.5'))
        self.assertAlmostEqual(build.volume(first),build.volume(second))
        self.assertNotEqual(build.signature(first),build.signature(second))

    def test_09_unknown_or_executable_operation_rejected(self):
        for operation in ('import_mesh','eval','__import__("os")',{},None):
            r=copy.deepcopy(SPEC['shapes'][0]);r['operation']=operation
            with self.assertRaises(ValueError):build.mesh_from_recipe(r)

    def test_10_external_asset_key_rejected(self):
        r=copy.deepcopy(SPEC['shapes'][0]);r['parameters']['mesh_path']='external.glb'
        with self.assertRaises(ValueError):build.mesh_from_recipe(r)

    def test_11_nonfinite_and_boolean_dimensions_rejected(self):
        for value in (True,False,float('nan'),float('inf'),-1,0,2,'0.5',None):
            r=copy.deepcopy(SPEC['shapes'][0]);r['parameters']['size'][0]=value
            with self.assertRaises(ValueError):build.mesh_from_recipe(r)

    def test_12_missing_parameter_rejected(self):
        for recipe in SPEC['shapes']:
            r=copy.deepcopy(recipe);r['parameters'].pop(next(iter(r['parameters'])))
            with self.assertRaises(ValueError):build.mesh_from_recipe(r)

    def test_13_duplicate_id_rejected(self):
        spec=copy.deepcopy(SPEC);spec['shapes'].append(spec['shapes'][0])
        with self.assertRaises(ValueError):build.build_catalogue(spec,RAW)

    def test_14_rotated_alias_rejected(self):
        spec=copy.deepcopy(SPEC)
        r=copy.deepcopy(next(r for r in spec['shapes'] if r['id']=='block.h0.5.w0.25'))
        r['id']='bad.rotated.alias'
        spec['aliases'].append(dict(id=r['id'],target='block.h0.25.w0.5',recipe=r,condition='same_pose_oriented_triangles'))
        with self.assertRaises(ValueError):build.build_catalogue(spec,RAW)

    def test_15_alias_cycle_rejected(self):
        spec=copy.deepcopy(SPEC);spec['aliases'][0]['target']=spec['aliases'][0]['id']
        with self.assertRaises(ValueError):build.build_catalogue(spec,RAW)

    def test_16_json_duplicate_keys_and_nonfinite_tokens_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'bad.json'
            for text in ('{"x":1,"x":2}','{"x":NaN}','{"x":Infinity}'):
                path.write_text(text,encoding='utf-8')
                with self.assertRaises(ValueError):build.load_spec(path)

    def test_17_python_imports_are_standard_library(self):
        for path in ROOT.rglob('*.py'):
            for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'),filename=str(path))):
                names=[n.name.split('.')[0] for n in node.names] if isinstance(node,ast.Import) else ([node.module.split('.')[0]] if isinstance(node,ast.ImportFrom) and node.module else [])
                for name in names:self.assertIn(name,sys.stdlib_module_names,str(path))

    def test_18_no_dynamic_code_in_builder(self):
        tree=ast.parse((ADDON/'build.py').read_text(encoding='utf-8'))
        names={node.func.id for node in ast.walk(tree) if isinstance(node,ast.Call) and isinstance(node.func,ast.Name)}
        self.assertFalse(names & {'eval','exec','compile','__import__'})

    def test_19_standalone_cli_reproduces_without_full_project(self):
        import shutil
        with tempfile.TemporaryDirectory() as folder:
            target=Path(folder)
            for name in ('build.py','recipes.json'):shutil.copyfile(ADDON/name,target/name)
            result=subprocess.run([sys.executable,str(target/'build.py'),'--out',str(target/'out')],capture_output=True,text=True,timeout=30)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertEqual((target/'out/catalogue.json').read_bytes(),(ADDON/'catalogue.json').read_bytes())

    def test_20_no_unrecorded_geometry_fields(self):
        for recipe in SPEC['shapes']:
            self.assertEqual(set(recipe),{'id','family','label','operation','parameters'})
            self.assertNotIn('vertices',recipe)
            self.assertNotIn('triangles',recipe)

    def test_21_recipe_and_catalogue_ids_are_one_to_one(self):
        self.assertEqual([r['id'] for r in SPEC['shapes']],[s['id'] for s in DATA['shapes']])
        self.assertEqual(set(DATA['aliases']),{a['id'] for a in SPEC['aliases']})

    def test_22_operation_boundaries(self):
        cases=[('stairs', 'steps', True),('stairs','steps',65),('column','inner',0.75),('column','segments',2),('roof_corner','inner',1),('frame','kind','mesh'),('quarter_curve','solid',1)]
        for op,key,value in cases:
            r=copy.deepcopy(next(r for r in SPEC['shapes'] if r['operation']==op));r['parameters'][key]=value
            with self.assertRaises(ValueError):build.mesh_from_recipe(r)

if __name__=='__main__':
    unittest.main(verbosity=2)
