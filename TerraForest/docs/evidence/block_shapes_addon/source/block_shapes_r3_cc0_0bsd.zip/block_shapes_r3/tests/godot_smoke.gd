# SPDX-License-Identifier: 0BSD
extends SceneTree
## Shipped runtime checks. NOT executed in the r2 authoring environment.
## godot --headless --path . --script tests/godot_smoke.gd
const Library = preload("res://addons/block_shapes/library.gd")
const World = preload("res://addons/block_shapes/world.gd")
var failures: int = 0
var checks: int = 0

func _initialize() -> void:
	call_deferred("_run")

func _check(ok: bool, text: String) -> bool:
	checks += 1
	if not ok:
		failures += 1
		push_error("FAIL: " + text)
	return ok

func _write(path: String, value: Variant) -> void:
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		_check(false, "write test fixture")
		return
	file.store_string(JSON.stringify(value))

func _run() -> void:
	var library = Library.new()
	if not _check(library.last_error.is_empty() and library.shapes.size() == 224, "224 catalogue entries"):
		quit(1)
		return
	_check(library.rotations.size() == 24, "rotation count")
	for i in range(library.shapes.size()):
		var mesh: ArrayMesh = library.create_mesh(i)
		_check(mesh.get_surface_count() == 1, "mesh surface %s" % i)
		var expected: int = library.shapes[i]["triangles"].size() * 3
		_check(mesh.get_faces().size() == expected, "triangle count %s" % i)
		for orientation in range(24):
			var prepared: Dictionary = library.prepared(i, orientation)
			_check(prepared["vertices"].size() == expected, "rotation %s/%s" % [i, orientation])
			for vertex in prepared["vertices"]:
				_check(vertex.x >= -0.00001 and vertex.x <= 1.00001 and vertex.y >= -0.00001 and vertex.y <= 1.00001 and vertex.z >= -0.00001 and vertex.z <= 1.00001, "rotated bounds")
	var corrected: ArrayMesh = library.create_mesh(library.find_shape("block.h0.5.w0.25"))
	_check(corrected.get_aabb().size.is_equal_approx(Vector3(0.25, 0.5, 1.0)), "formerly rotated alias now has correct axes")
	var bad: Variant = JSON.parse_string(FileAccess.get_file_as_string(Library.CATALOGUE_PATH))
	bad["shapes"][0]["triangles"][0][0] = 0.5
	_check(not Library.valid_catalogue(bad), "fractional triangle index rejected")
	var world = World.new()
	world.collision_enabled = false
	root.add_child(world)
	_check(world.set_block(Vector3i(15, 0, 0), "cube.full"), "first cube")
	_check(world.set_block(Vector3i(16, 0, 0), "cube.full", 7), "neighbor cube")
	world.flush()
	_check(world.statistics()["triangles"] == 20, "cross-chunk face culling")
	_check(world.statistics()["chunks"] == 2, "two chunks")
	_check(world.save_world("user://block_shapes.smoke.json"), "save")
	var saved := FileAccess.get_file_as_string("user://block_shapes.smoke.json")
	_check(world.save_world("user://block_shapes.smoke.json"), "second save")
	_check(saved == FileAccess.get_file_as_string("user://block_shapes.smoke.json"), "deterministic saves")
	world.clear()
	_check(world.load_world("user://block_shapes.smoke.json"), "load")
	world.flush()
	_check(world.statistics()["triangles"] == 20, "loaded geometry")
	var valid_save: Dictionary = JSON.parse_string(saved)
	var invalid_save: Dictionary = valid_save.duplicate(true)
	invalid_save["cell_size"] = []
	_write("user://block_shapes.invalid.json", invalid_save)
	_check(not world.load_world("user://block_shapes.invalid.json"), "malformed numeric field rejected")
	_check(world.statistics()["blocks"] == 2, "failed load preserves current world")
	invalid_save = valid_save.duplicate(true)
	invalid_save["blocks"].append(invalid_save["blocks"][0])
	_write("user://block_shapes.invalid.json", invalid_save)
	_check(not world.load_world("user://block_shapes.invalid.json"), "duplicate cells rejected")
	_check(world.statistics()["blocks"] == 2, "duplicate rejection is atomic")
	world.remove_block(Vector3i(16, 0, 0))
	world.flush()
	_check(world.statistics()["triangles"] == 12, "exposed neighbor rebuilt")
	world.clear()
	world.non_occluding_materials = PackedInt32Array([1])
	world.set_block(Vector3i(-1, 0, 0), "cube.full", 0, 1)
	world.set_block(Vector3i(0, 0, 0), "cube.full", 0, 1)
	world.flush()
	_check(world.statistics()["triangles"] == 24, "non-occluding materials preserve neighbor faces")
	_check(world.statistics()["chunks"] == 2, "negative coordinates chunk correctly")
	world.non_occluding_materials = PackedInt32Array()
	world.refresh_all()
	world.flush()
	_check(world.statistics()["triangles"] == 20, "refresh_all restores opaque culling")
	world.collision_enabled = true
	world.refresh_all()
	world.flush()
	var collision_bodies := 0
	for chunk_node in world.get_children():
		if chunk_node.get_node_or_null("Collision") != null:
			collision_bodies += 1
	_check(collision_bodies == 2, "static collision bodies generated")
	var mesh_library: MeshLibrary = library.create_mesh_library()
	_check(mesh_library.get_item_list().size() == 224, "MeshLibrary count")
	_check(ResourceSaver.save(mesh_library, "user://block_shapes.smoke.tres") == OK, "MeshLibrary save")
	world.free()
	await process_frame
	print("RESULT: %s checks, %s failures" % [checks, failures])
	if failures == 0:
		print("PASS: Godot runtime smoke")
	quit(0 if failures == 0 else 1)
