# SPDX-License-Identifier: 0BSD
"""Negative tests for the inventory verifier. Python standard library only."""
from __future__ import annotations
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('inventory',ROOT/'addons/block_shapes/verify.py')
v=importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)

class InventoryTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        (self.root/'example.py').write_text('# SPDX-License-Identifier: 0BSD\nprint(1)\n',encoding='utf-8')
        self.manifest={'format':2,'license':'CC0-1.0','files':{'example.py':{'sha256':v.digest(self.root/'example.py'),'bytes':(self.root/'example.py').stat().st_size,'license_id':'0BSD','origin':{'method':'test_fixture','record':'synthetic test input'}}}}
        self.write_manifest()
    def tearDown(self):self.temp.cleanup()
    def write_manifest(self):
        (self.root/'MANIFEST.json').write_text(json.dumps(self.manifest),encoding='utf-8')
    def verify(self):
        with contextlib.redirect_stdout(io.StringIO()):return v.verify_manifest(self.root)
    def test_01_valid_inventory(self):self.assertEqual(self.verify(),1)
    def test_02_modified_source_rejected(self):
        (self.root/'example.py').write_text('print(2)',encoding='utf-8')
        with self.assertRaises(ValueError):self.verify()
    def test_03_missing_source_rejected(self):
        (self.root/'example.py').unlink()
        with self.assertRaises(ValueError):self.verify()
    def test_04_unrecorded_extra_rejected(self):
        (self.root/'unknown.glb').write_bytes(b'not a real model')
        with self.assertRaises(ValueError):self.verify()
    def test_05_unmapped_license_rejected(self):
        self.manifest['files']['example.py']['license_id']='MIT';self.write_manifest()
        with self.assertRaises(ValueError):self.verify()
    def test_06_software_mislabeled_as_content_rejected(self):
        self.manifest['files']['example.py']['license_id']='CC0-1.0';self.write_manifest()
        with self.assertRaises(ValueError):self.verify()
    def test_07_unknown_origin_rejected(self):
        self.manifest['files']['example.py'].pop('origin');self.write_manifest()
        with self.assertRaises(ValueError):self.verify()
    def test_08_path_escape_absolute_backslash_colon_rejected(self):
        for name in ('../outside','/etc/passwd','C:/temp','a/../example.py','a\\b','a//b','./example.py'):
            with self.subTest(path=name),self.assertRaises(ValueError):v.checked_path(self.root,name)
    def test_09_symlink_rejected(self):
        link=self.root/'pointer.py'
        try:link.symlink_to(self.root/'example.py')
        except OSError:self.skipTest('Host does not permit symlink creation')
        with self.assertRaises(ValueError):self.verify()
    def test_10_invalid_uid_file_rejected(self):
        (self.root/'example.gd.uid').write_text('not a Godot UID',encoding='utf-8')
        with self.assertRaises(ValueError):self.verify()
    def test_11_valid_godot_cache_uid_allowed(self):
        (self.root/'example.gd.uid').write_text('uid://abc123\n',encoding='utf-8')
        self.assertEqual(self.verify(),1)
    def test_12_manifest_cannot_claim_self_hash(self):
        self.manifest['files']['MANIFEST.json']=self.manifest['files']['example.py'];self.write_manifest()
        with self.assertRaises(ValueError):self.verify()

if __name__=='__main__':unittest.main(verbosity=2)
