# SPDX-License-Identifier: 0BSD
"""Missing engine tests must never be mistaken for completed validation."""
from __future__ import annotations
import contextlib
import importlib.util
import io
from pathlib import Path
import subprocess
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('release_gate', ROOT/'tools/check.py')
gate=importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)


class GateTests(unittest.TestCase):
    def invoke(self, args):
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            return gate.main(args)

    def test_01_no_engine_is_not_success(self):
        with patch.object(gate,'source_checks'), patch.object(gate,'resolve_engine',return_value=None):
            self.assertEqual(self.invoke([]),2)

    def test_02_explicit_source_only_is_success(self):
        with patch.object(gate,'source_checks'), patch.object(gate,'engine_checks') as engine:
            self.assertEqual(self.invoke(['--source-only']),0)
            engine.assert_not_called()

    def test_03_engine_failure_is_not_success(self):
        with patch.object(gate,'source_checks'), patch.object(gate,'resolve_engine',return_value='fake'), patch.object(gate,'engine_checks',side_effect=ValueError('failed')):
            self.assertEqual(self.invoke([]),1)

    def test_04_exit_zero_with_script_error_is_failure(self):
        result=subprocess.CompletedProcess(['fake'],0,'SCRIPT ERROR: example','')
        with patch.object(gate.subprocess,'run',return_value=result), contextlib.redirect_stdout(io.StringIO()), self.assertRaises(ValueError):
            gate.run(['fake'],engine=True)

    def test_05_missing_success_marker_is_failure(self):
        result=subprocess.CompletedProcess(['fake'],0,'Godot started','')
        with patch.object(gate.subprocess,'run',return_value=result), contextlib.redirect_stdout(io.StringIO()), self.assertRaises(ValueError):
            gate.run(['fake'],engine=True,required='PASS: Godot runtime smoke')

    def test_06_genuine_completion_marker_accepted(self):
        result=subprocess.CompletedProcess(['fake'],0,'PASS: Godot runtime smoke','')
        with patch.object(gate.subprocess,'run',return_value=result), contextlib.redirect_stdout(io.StringIO()):
            self.assertIn('PASS:',gate.run(['fake'],engine=True,required='PASS: Godot runtime smoke'))

    def test_07_nonzero_exit_is_failure(self):
        result=subprocess.CompletedProcess(['fake'],1,'','failed')
        with patch.object(gate.subprocess,'run',return_value=result), contextlib.redirect_stdout(io.StringIO()), self.assertRaises(ValueError):
            gate.run(['fake'],engine=True)

    def test_08_source_gate_failure_is_failure(self):
        with patch.object(gate,'source_checks',side_effect=ValueError('licence mismatch')):
            self.assertEqual(self.invoke(['--source-only']),1)


if __name__=='__main__': unittest.main()
