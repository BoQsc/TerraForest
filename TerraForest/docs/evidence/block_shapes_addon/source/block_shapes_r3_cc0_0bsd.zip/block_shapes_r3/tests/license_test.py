# SPDX-License-Identifier: 0BSD
"""Licence policy checks independent of trusting a refreshed file hash."""
from __future__ import annotations
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
ADDON = ROOT / 'addons/block_shapes'
spec = importlib.util.spec_from_file_location('license_audit', ADDON / 'audit.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


class LicenseTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / 'addon'
        shutil.copytree(ADDON, self.root, ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.gd.uid'))

    def scan(self):
        # Skip hash validation to show that substantive checks also catch a
        # problem after somebody regenerates a matching integrity manifest.
        return audit.audit(self.root, check_integrity=False)

    def test_01_licence_policy_passes(self):
        result = self.scan()
        self.assertEqual(result['result'], 'PASS')
        self.assertEqual(result['bundled_external_implementation_dependencies'], [])

    def test_02_mit_header_rejected_even_with_0bsd_manifest(self):
        path = self.root / 'library.gd'
        path.write_text(path.read_text().replace('SPDX-License-Identifier: 0BSD', 'SPDX-License-Identifier: MIT'))
        with self.assertRaisesRegex(ValueError, 'SPDX'): self.scan()

    def test_03_missing_header_rejected(self):
        path = self.root / 'world.gd'
        path.write_text('\n'.join(path.read_text().splitlines()[1:]))
        with self.assertRaisesRegex(ValueError, 'SPDX'): self.scan()

    def test_04_changed_legal_text_rejected(self):
        with (self.root/'LICENSE.0BSD.txt').open('a') as file: file.write('\nNon-commercial use only.\n')
        with self.assertRaisesRegex(ValueError, 'legal text'): self.scan()

    def test_05_third_party_python_import_rejected(self):
        with self.assertRaisesRegex(ValueError, 'unapproved Python import'):
            audit.check_python('import requests', 'build.py', self.root)

    def test_06_standard_library_import_accepted(self):
        self.assertEqual(audit.check_python('import math\nfrom pathlib import Path', 'x.py', self.root), {'math','pathlib'})

    def test_07_dynamic_python_execution_rejected(self):
        for expression in ('eval("1")','exec("x=1")','__import__("math")','compile("1","x","eval")'):
            with self.subTest(expression=expression), self.assertRaises(ValueError):
                audit.check_python(expression, 'x.py', self.root)

    def test_08_external_godot_addon_rejected(self):
        with self.assertRaisesRegex(ValueError, 'outside this addon'):
            audit.check_gd('const Other = preload("res://addons/other/file.gd")', 'x.gd', self.root, False)

    def test_09_own_godot_preload_accepted(self):
        result = audit.check_gd('const Own = preload("res://addons/block_shapes/world.gd")', 'x.gd', self.root, False)
        self.assertEqual(len(result),1)

    def test_10_dynamic_resource_loading_rejected(self):
        with self.assertRaisesRegex(ValueError, 'literal'):
            audit.check_gd('var x = load(path)', 'x.gd', self.root, False)

    def test_11_missing_own_resource_rejected(self):
        with self.assertRaisesRegex(ValueError, 'missing/escaping'):
            audit.check_gd('var x = load("res://addons/block_shapes/unknown.gd")', 'x.gd', self.root, False)

    def test_12_network_runtime_rejected(self):
        with self.assertRaisesRegex(ValueError, 'external/dynamic'):
            audit.check_gd('var x = HTTPRequest.new()', 'x.gd', self.root, False)

    def test_13_comments_and_strings_do_not_load_code(self):
        source = '# preload("res://external.gd")\nvar note = "HTTPRequest.new() load(path)"\n'
        self.assertEqual(audit.check_gd(source, 'x.gd', self.root, False), set())

    def test_14_external_svg_image_rejected(self):
        with self.assertRaises(ValueError):
            audit.check_svg('<svg><image href="https://example.invalid/image.png"/></svg>', 'x.svg')

    def test_15_svg_entity_rejected(self):
        with self.assertRaises(ValueError):
            audit.check_svg('<!DOCTYPE svg><svg/>', 'x.svg')

    def test_16_numeric_svg_accepted(self):
        audit.check_svg('<svg><polygon points="0,0 1,0 0,1"/></svg>', 'x.svg')

    def test_17_foreign_binary_cannot_be_added_as_cc0(self):
        manifest_path = self.root/'MANIFEST.json'
        manifest = json.loads(manifest_path.read_text())
        manifest['files']['external.dll'] = {'kind':'project_content','license_id':'CC0-1.0'}
        manifest_path.write_text(json.dumps(manifest))
        (self.root/'external.dll').write_bytes(b'MZbinary')
        with self.assertRaisesRegex(ValueError, 'file type'): self.scan()

    def test_18_conflicting_json_licence_rejected(self):
        path = self.root/'recipes.json'
        data = json.loads(path.read_text()); data['license'] = 'CC-BY-4.0'
        path.write_text(json.dumps(data))
        with self.assertRaisesRegex(ValueError, 'JSON licence'): self.scan()

    def test_19_legal_reference_unchanged(self):
        import hashlib
        for licence, filename in [('0BSD','LICENSE.0BSD.txt'),('CC0-1.0','LICENSE.CC0-1.0.txt')]:
            self.assertEqual(hashlib.sha256((ADDON/filename).read_bytes()).hexdigest(), audit.LEGAL_HASHES[licence])

    def test_20_embedded_binary_text_rejected(self):
        path = self.root/'README.md'; path.write_bytes(path.read_bytes()+b'\0')
        with self.assertRaisesRegex(ValueError, 'binary payload'): self.scan()


if __name__ == '__main__': unittest.main()
