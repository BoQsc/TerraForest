<!-- SPDX-License-Identifier: CC0-1.0 -->
# Block Shapes — release licence declaration

**Software: BSD Zero Clause License (0BSD).** All GDScript, Python, scenes,
project/plugin configuration and test launchers in this distribution are
provided under 0BSD. The complete standard text is `LICENSE.0BSD.txt` in the
addon and `licenses/0BSD.txt` in the full project.

**Assets and project-authored content: CC0 1.0 Universal (CC0-1.0).** Numerical
shape recipes, all generated geometry and catalogue data, numerical material
settings, project-authored documentation, previews and inventory/report
metadata are dedicated under CC0-1.0. The complete standard text, including
its fallback licence, is `LICENSE.CC0-1.0.txt` in the addon and
`licenses/CC0-1.0.txt` in the full project.

This is the actual release licence split, not a plan to add licences later.
`MANIFEST.json` specifies the component of every distributed file. No
attribution, registration, payment, source-disclosure, non-commercial-use or
provenance-retention requirement is added. Contributor review procedures are
maintenance rules, not extra licence restrictions on users.

There are no bundled external implementation libraries, engine binaries, font
files, downloaded models or extracted game assets in the checked source
package. Both legal texts are preserved as standard legal documents, not
misrepresented as newly created project art. Assets a user independently adds
retain their own terms. This licence declaration cannot relicense those assets.

## Origins and scope

These release choices implement the requesting user's instructions for this
AI-assisted project. The inspected and regenerated geometry is produced from
the included numerical recipes. `ORIGIN.md` records the actual earlier-project
ancestry and this revision's work; no separate clean-room authoring team or
human signature is invented. Static checks confirm the declared file/dependency
policy; they do not detect all possible third-party copyright similarities.
The standard licences' own limitations and disclaimers apply unchanged.

## Separate host software

Godot and Python are external host/tools, not distributed or relicensed here.
Godot's MIT licence and its third-party notices still apply to engine binaries
that a game distributor includes. This does not change the addon's 0BSD/CC0
licensing. The build tools use only Python's standard library; Python is not
needed by the runtime addon.

Primary terms: https://opensource.org/license/0bsd and
https://creativecommons.org/publicdomain/zero/1.0/legalcode.en .
Engine boundary: https://godotengine.org/license/ .
