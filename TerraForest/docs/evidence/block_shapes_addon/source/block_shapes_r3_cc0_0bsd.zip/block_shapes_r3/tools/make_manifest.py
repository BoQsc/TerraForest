# SPDX-License-Identifier: 0BSD
"""Explicitly refresh inventories from the accepted per-file origin map.
Refuses unlisted files. Updating hashes is NOT approval of ownership/origin.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
ADDON=ROOT/'addons/block_shapes'
SKIP_DIRS={'.git','.godot','__pycache__'}
MANIFESTS={'MANIFEST.json','addons/block_shapes/MANIFEST.json'}


def files() -> set[str]:
    result=set()
    for path in ROOT.rglob('*'):
        relative=path.relative_to(ROOT)
        if any(part in SKIP_DIRS for part in relative.parts):continue
        if path.is_symlink():raise ValueError(f'Symlink forbidden: {relative}')
        if not path.is_file() or path.suffix=='.pyc' or path.name.endswith('.gd.uid'):continue
        name=relative.as_posix()
        if name not in MANIFESTS:result.add(name)
    return result


def entry(path: Path, accepted: dict) -> dict:
    result=dict(accepted)
    result['bytes']=path.stat().st_size
    result['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    return result


def write(path: Path, entries: dict) -> None:
    obj={'format':2,'license':'CC0-1.0',
         'scope':'Unsigned payload integrity, declared origin and licence scope; not legal clearance.',
         'self_hash':'This MANIFEST.json is excluded from its own inventory. Identify the distribution using the separately supplied archive SHA-256.',
         'files':dict(sorted(entries.items()))}
    path.write_text(json.dumps(obj,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--write',action='store_true',help='Explicitly update the two manifest files')
    args=parser.parse_args()
    if not args.write:parser.error('Use --write only after reviewing changes and provenance/files.json')
    mapping=json.loads((ROOT/'provenance/files.json').read_text(encoding='utf-8'))['files']
    actual=files()
    expected=set(mapping)-MANIFESTS
    if actual!=expected:
        raise ValueError(f'Inventory mismatch; unlisted={sorted(actual-expected)}, missing={sorted(expected-actual)}')
    addon_entries={}
    for relative,accepted in mapping.items():
        if relative.startswith('addons/block_shapes/') and relative not in MANIFESTS:
            addon_entries[relative.removeprefix('addons/block_shapes/')]=entry(ROOT/relative,accepted)
    write(ADDON/'MANIFEST.json',addon_entries)
    all_entries={relative:entry(ROOT/relative,accepted) for relative,accepted in mapping.items() if relative!='MANIFEST.json'}
    write(ROOT/'MANIFEST.json',all_entries)
    print(f'WROTE: {len(all_entries)} full-project files and {len(addon_entries)} addon files')
    print('Hash refresh does not approve origin, rights or legal clearance.')

if __name__=='__main__':main()
