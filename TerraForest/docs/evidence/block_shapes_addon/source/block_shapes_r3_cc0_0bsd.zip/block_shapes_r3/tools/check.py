# SPDX-License-Identifier: 0BSD
"""Run licence, geometry and Godot gates. Missing Godot is NOT a release pass.
Use --source-only explicitly for an offline source-only check. No downloads.
"""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
ERROR_MARKERS = ('SCRIPT ERROR:', 'Parse Error:', 'ERROR:')


def run(command: list[str], cwd: Path = ROOT, timeout: int = 120,
        engine: bool = False, required: str = '', environment: dict | None = None) -> str:
    env = os.environ.copy()
    env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1')
    if environment: env.update(environment)
    result = subprocess.run(command, cwd=cwd, capture_output=True, text=True,
                            encoding='utf-8', errors='replace', timeout=timeout, env=env)
    output = result.stdout + '\n' + result.stderr
    print(output.strip(), flush=True)
    if result.returncode or (engine and any(marker in output for marker in ERROR_MARKERS)):
        raise ValueError(f'Command failed: {command[0]} (exit {result.returncode})')
    if required and required not in output:
        raise ValueError(f'Expected test completion marker was absent: {required}')
    return output


def resolve_engine(explicit: str | None) -> str | None:
    candidate = explicit or os.environ.get('GODOT')
    if candidate:
        located = shutil.which(candidate)
        path = Path(located or candidate).expanduser()
        return str(path.resolve()) if path.is_file() else None
    for name in ('godot', 'godot4', 'Godot.exe', 'godot.exe'):
        located = shutil.which(name)
        if located: return str(Path(located).resolve())
    return None


def source_checks() -> None:
    run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-p', '*_test.py', '-v'])
    run([sys.executable, 'tools/verify_provenance.py', '--rebuild'])
    run([sys.executable, 'addons/block_shapes/audit.py', '--root', '.'])
    run([sys.executable, 'addons/block_shapes/audit.py'])


def engine_checks(engine: str) -> None:
    version = run([engine, '--version'], engine=True).strip()
    if not re.match(r'^4\.[0-9]+(?:\.[0-9]+)?\.', version):
        raise ValueError('A Godot 4 editor executable is required')
    # Tests run on a copy. Do not import into or overwrite the user's project.
    with tempfile.TemporaryDirectory(prefix='block_shapes_engine_') as folder:
        base = Path(folder)
        project = base / 'project'
        shutil.copytree(ROOT, project, ignore=shutil.ignore_patterns('.godot','.git','__pycache__','*.pyc','*.gd.uid'))
        home = base / 'user-data'; home.mkdir()
        env = {'XDG_DATA_HOME': str(home), 'XDG_CONFIG_HOME': str(home),
               'APPDATA': str(home), 'LOCALAPPDATA': str(home)}
        args = [engine, '--headless', '--path', str(project)]
        run(args + ['--editor', '--import'], project, engine=True, environment=env)
        run(args + ['--script', 'res://tests/godot_smoke.gd'], project, engine=True,
            required='PASS: Godot runtime smoke', environment=env)
        run(args + ['--quit-after', '30'], project, engine=True, environment=env)
        # Test the actual export hook, not a manually copied catalogue. Export
        # a resource pack only; the engine is not included or relicensed.
        preset = '''; SPDX-License-Identifier: 0BSD
[preset.0]
name="Block Shapes validation"
platform="Linux"
runnable=true
dedicated_server=false
custom_features=""
export_filter="all_resources"
include_filter=""
exclude_filter="docs/*,tools/*,provenance/*,*.py,*.md,*.txt,*.svg"
export_path=""
script_export_mode=0
[preset.0.options]
binary_format/architecture="x86_64"
'''
        (project / 'export_presets.cfg').write_text(preset, encoding='utf-8')
        pack = base / 'validation.pck'
        run(args + ['--export-pack', 'Block Shapes validation', str(pack)], project,
            engine=True, environment=env)
        if not pack.is_file() or pack.stat().st_size == 0:
            raise ValueError('Godot did not create the validation resource pack')
        isolated = base / 'pack-only'; isolated.mkdir()
        # No source project in the working directory: omitted catalogue data
        # cannot accidentally be read from the authoring tree.
        run([engine, '--headless', '--main-pack', str(pack), '--script',
             'res://tests/godot_smoke.gd'], isolated, engine=True,
            required='PASS: Godot runtime smoke', environment=env)
        run([engine, '--headless', '--main-pack', str(pack), '--quit-after', '30'],
            isolated, engine=True, environment=env)
    print('PASS: Godot import, runtime smoke, demo boot, resource export and isolated-pack tests.')
    print('Headless checks do not establish visual quality or large-world performance.')


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--source-only', action='store_true', help='Explicitly skip engine gates; not a release validation')
    mode.add_argument('--godot', help='Path to a local Godot 4 editor; otherwise use GODOT or PATH')
    args = parser.parse_args(argv)
    try:
        source_checks()
        if args.source_only:
            print('PASS: source-only checks. NOT RUN: Godot; complete-release status is not granted.')
            return 0
        engine = resolve_engine(args.godot)
        if engine is None:
            print('BLOCKED: Godot 4 editor not found. Runtime/export gates NOT RUN. This is NOT a complete-release pass.', file=sys.stderr)
            return 2
        engine_checks(engine)
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        print(f'FAIL: {error}', file=sys.stderr)
        return 1
    print('PASS: all requested automated gates. No legal-clearance or visual-review certification is implied.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
