# SPDX-License-Identifier: 0BSD
"""Verify both inventories; optionally rebuild catalogue and derived documents."""
from __future__ import annotations
import argparse
import importlib.util
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
ADDON = ROOT/'addons/block_shapes'
spec = importlib.util.spec_from_file_location('inventory_verifier', ADDON/'verify.py')
verifier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verifier)
GENERATED = ('addons/block_shapes/catalogue.json', 'docs/catalogue.summary.json',
             'docs/CATALOGUE.md', 'docs/shapes.preview.svg')


def rebuild() -> None:
    with tempfile.TemporaryDirectory(prefix='block_shapes_full_') as folder:
        work = Path(folder)/'project'
        shutil.copytree(ROOT, work, ignore=shutil.ignore_patterns('.git','.godot','__pycache__','*.pyc','*.gd.uid'))
        env = os.environ.copy()
        env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
        for relative in ('tools/generate.py','tools/preview.py'):
            result = subprocess.run([sys.executable,str(work/relative)],cwd=work,capture_output=True,
                                    text=True,encoding='utf-8',errors='replace',timeout=45,env=env)
            if result.returncode:
                raise ValueError(f'Regeneration failed: {relative}\n{result.stdout}\n{result.stderr}')
        for relative in GENERATED:
            if (work/relative).read_bytes() != (ROOT/relative).read_bytes():
                raise ValueError('Regenerated file differs: '+relative)
            print('PASS: byte-identical '+relative)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rebuild',action='store_true')
    args = parser.parse_args()
    try:
        verifier.verify_manifest(ROOT)
        verifier.verify_manifest(ADDON)
        if args.rebuild:
            verifier.rebuild(ADDON)
            rebuild()
    except (OSError,ValueError,TypeError,KeyError,subprocess.SubprocessError) as error:
        print('FAIL: '+str(error),file=sys.stderr)
        return 1
    print('Integrity/reproducibility verified; not legal clearance or a signed attestation.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
