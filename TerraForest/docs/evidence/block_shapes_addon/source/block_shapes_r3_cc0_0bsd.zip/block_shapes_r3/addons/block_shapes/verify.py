# SPDX-License-Identifier: 0BSD
"""Verify package inventory and optionally reproduce numeric geometry.
Integrity and reproducibility are not proof of authorship or legal clearance.
No network calls, downloads, automatic manifest updates, or third-party imports.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tempfile

IGNORED_DIRS = {'.git', '.godot', '__pycache__'}
CODE_SUFFIXES = {'.py', '.gd', '.cfg', '.godot', '.tscn', '.bat', '.sh'}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def checked_path(root: Path, relative: str) -> Path:
    if not isinstance(relative, str) or not relative or '\\' in relative or ':' in relative or '\x00' in relative:
        raise ValueError(f'Invalid manifest path: {relative!r}')
    pure = PurePosixPath(relative)
    if pure.is_absolute() or pure.as_posix() != relative or any(part in ('.', '..') for part in pure.parts):
        raise ValueError(f'Non-canonical or escaping manifest path: {relative!r}')
    path = root
    for part in pure.parts:
        path = path / part
        if path.is_symlink():
            raise ValueError(f'Symlink not accepted in source inventory: {relative}')
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError(f'Manifest path leaves package: {relative}')
    return path


def payload_files(root: Path) -> set[str]:
    files = set()
    for folder, dirs, names in os.walk(root, followlinks=False):
        base = Path(folder)
        for name in dirs + names:
            if (base / name).is_symlink():
                raise ValueError(f'Symlink not accepted: {(base / name).relative_to(root)}')
        dirs[:] = [name for name in dirs if name not in IGNORED_DIRS]
        for name in names:
            path = base / name
            if path.suffix == '.pyc':
                continue
            if name.endswith('.gd.uid'):
                # Godot may create UID companions on first import. Ignore only
                # the native text form, not arbitrary files ending in .uid.
                if not re.fullmatch(r'uid://[a-z0-9]+\s*', path.read_text(encoding='utf-8')):
                    raise ValueError(f'Invalid generated Godot UID file: {name}')
                continue
            files.add(path.relative_to(root).as_posix())
    return files


def verify_manifest(root: Path) -> int:
    root = root.resolve()
    manifest_path = root / 'MANIFEST.json'
    if manifest_path.is_symlink():
        raise ValueError('Manifest itself is a symlink')
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    if manifest.get('format') != 2 or manifest.get('license') != 'CC0-1.0':
        raise ValueError('Expected manifest format 2 with CC0-1.0 metadata')
    entries = manifest.get('files')
    if not isinstance(entries, dict) or not entries:
        raise ValueError('Manifest has no file inventory')
    if 'MANIFEST.json' in entries:
        raise ValueError('Manifest cannot record its own payload hash')
    for relative, entry in entries.items():
        path = checked_path(root, relative)
        if not isinstance(entry, dict) or not path.is_file():
            raise ValueError(f'Missing file or invalid manifest entry: {relative}')
        if digest(path) != entry.get('sha256') or path.stat().st_size != entry.get('bytes'):
            raise ValueError(f'File digest/size mismatch: {relative}')
        if not isinstance(entry.get('origin'), dict) or not entry['origin'].get('method') or not entry['origin'].get('record'):
            raise ValueError(f'Missing origin classification: {relative}')
        if entry.get('kind') == 'standard_license_text':
            if entry.get('license_reference') not in ('0BSD', 'CC0-1.0') or 'license_id' in entry:
                raise ValueError(f'Invalid legal-reference classification: {relative}')
        else:
            licence = entry.get('license_id')
            if licence not in ('0BSD', 'CC0-1.0'):
                raise ValueError(f'Unexpected licence classification: {relative}')
            expected = '0BSD' if path.suffix in CODE_SUFFIXES else 'CC0-1.0'
            if licence != expected:
                raise ValueError(f'Software/content licence split violated: {relative}')
    extras = payload_files(root) - set(entries) - {'MANIFEST.json'}
    if extras:
        raise ValueError('Unrecorded files: ' + ', '.join(sorted(extras)))
    print(f'PASS: {len(entries)} inventoried files, hashes, sizes, licence scopes and origin records')
    return len(entries)


def rebuild(addon: Path) -> None:
    with tempfile.TemporaryDirectory(prefix='block_shapes_recipe_') as folder:
        work = Path(folder)
        for name in ('build.py', 'recipes.json'):
            shutil.copyfile(addon / name, work / name)
        environment = os.environ.copy()
        environment['PYTHONDONTWRITEBYTECODE'] = '1'
        environment['PYTHONUTF8'] = '1'
        result = subprocess.run([sys.executable, str(work/'build.py'), '--out', str(work/'out')],
                                capture_output=True, text=True, encoding='utf-8',
                                errors='replace', timeout=45, env=environment)
        if result.returncode:
            raise ValueError(f'Recipe rebuild failed:\n{result.stdout}\n{result.stderr}')
        if (work/'out/catalogue.json').read_bytes() != (addon/'catalogue.json').read_bytes():
            raise ValueError('Rebuilt catalogue differs')
        print('PASS: byte-identical catalogue from standalone recipes + builder')


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--rebuild', action='store_true')
    args = parser.parse_args()
    try:
        verify_manifest(args.root)
        if args.rebuild:
            rebuild(args.root)
    except (OSError, ValueError, TypeError, KeyError, subprocess.SubprocessError) as error:
        print(f'FAIL: {error}', file=sys.stderr)
        return 1
    print('No legal clearance or signer identity is established by these checks.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
