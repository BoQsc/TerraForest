<!-- SPDX-License-Identifier: CC0-1.0 -->
# Provenance

The current r2 origin record is `ORIGIN.md`; machine-readable incoming archive
and source identities are in `ORIGIN.json`. Exact file hashes and licence
classifications are in `MANIFEST.json`. The previous versions are not claimed
to have been independently clean-room certified.
