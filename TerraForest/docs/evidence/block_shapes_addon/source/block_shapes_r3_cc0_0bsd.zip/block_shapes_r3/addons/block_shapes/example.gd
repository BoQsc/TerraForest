# SPDX-License-Identifier: 0BSD
extends Node3D
## Attach to a Node3D in an otherwise empty Godot 4 scene.
const Construction = preload("res://addons/block_shapes/world.gd")

func _ready() -> void:
	var world = Construction.new()
	add_child(world)
	world.set_block(Vector3i(0, 0, 0), "cube.full")
	world.set_block(Vector3i(1, 0, 0), "ramp.h1.w1")
	world.flush()
