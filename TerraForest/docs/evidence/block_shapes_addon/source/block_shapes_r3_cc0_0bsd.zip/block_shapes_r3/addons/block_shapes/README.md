<!-- SPDX-License-Identifier: CC0-1.0 -->
# Block Shapes r3 — standalone addon

**0BSD code; CC0-1.0 recipes, generated geometry and project content.**
The licence split is applied now; see `LICENSE.md` and the per-file manifest.

Copy this directory to `res://addons/block_shapes`. Enable the Block Shapes
plugin to export the numeric catalogue correctly and to create a MeshLibrary
for Godot GridMap. Use GridMap cell size 1,1,1. The custom world mesher and
native GridMap are separate paths; GridMap does not use the custom culler.

The addon contains 224 stored meshes, three exact-pose ID aliases and 24 proper
rotations. `build.py` + `recipes.json` reproduce `catalogue.json` using Python's
standard library. No Python interpreter is required by the game.

```gdscript
extends Node3D
const Construction = preload("res://addons/block_shapes/world.gd")
func _ready() -> void:
    var building = Construction.new()
    add_child(building)
    building.set_block(Vector3i.ZERO, "cube.full")
    building.set_block(Vector3i(1, 0, 0), "ramp.h1.w1")
    building.flush()
```

Inside this directory:

    python audit.py
    python verify.py --rebuild

`audit.py` checks the declared licensing/dependency policy; `verify.py`
checks payload hashes and reproduces geometry. Neither executes Godot.
The full project includes the demo and a test runner requiring actual Godot
for runtime/export validation. **Those engine checks remain NOT RUN in this
authoring environment.** A source-only pass is not a complete-release pass.

Retained r2 runtime: sparse editable cells; chunk/material batching;
full-neighbour-boundary face culling; static collision; JSON save/load.
No streaming/LOD/GPU meshing or large-world performance guarantee.
`world.gd` configuration documents its current constraints. Do not change
cell/chunk size after adding blocks. Material/occlusion/collision changes
require `refresh_all()`.

No engine, font, binary library, extracted game asset or third-party addon
implementation is bundled. Actual project ancestry is kept in `ORIGIN.md`;
this is not a separately staffed clean-room reimplementation.
