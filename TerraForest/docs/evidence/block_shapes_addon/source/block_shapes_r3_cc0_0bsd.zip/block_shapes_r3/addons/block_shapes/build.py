# SPDX-License-Identifier: 0BSD
"""Block Shapes r2 recipe builder. Python 3.10+, standard library only.
Geometry helpers derive from this project's supplied r1 source; see ORIGIN.md.
Input: recipes.json (whitelisted numerical operations, no executable recipes).
Output: catalogue.json (CC0-1.0 data, not GDScript source).
Run: python build.py --out PATH
"""
from __future__ import annotations
import argparse
import hashlib
import re
import sys
import itertools
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EPS = 1e-8

def sub(a, b): return tuple(x-y for x, y in zip(a, b))
def dot(a, b): return sum(x*y for x, y in zip(a, b))
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def cross2(a, b, c): return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

def triangulate(poly):
    """Ear clipping for a simple 2D polygon, returning CCW triangles."""
    p = list(poly)
    area = sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(p, p[1:]+p[:1]))
    order = list(range(len(p)))
    if area < 0: order.reverse()
    result = []
    while len(order) > 3:
        found = False
        for j, b in enumerate(order):
            a, c = order[j-1], order[(j+1) % len(order)]
            if cross2(p[a], p[b], p[c]) <= EPS: continue
            blocked = False
            for k in order:
                if k in (a,b,c): continue
                if all(v >= -EPS for v in (cross2(p[a],p[b],p[k]),cross2(p[b],p[c],p[k]),cross2(p[c],p[a],p[k]))):
                    blocked = True; break
            if blocked: continue
            result.append((a,b,c)); del order[j]; found=True; break
        if not found: raise ValueError('Non-simple or degenerate polygon: '+repr(poly))
    result.append(tuple(order))
    return result

class Mesh:
    def __init__(self):
        self.vertices=[]; self.triangles=[]; self._lookup={}
    def vertex(self, p):
        p=tuple(0.0 if abs(x)<1e-10 else round(float(x),8) for x in p)
        if p not in self._lookup:
            self._lookup[p]=len(self.vertices); self.vertices.append(p)
        return self._lookup[p]
    def triangle(self, a,b,c, normal=None):
        n=cross(sub(b,a),sub(c,a))
        if dot(n,n)<1e-16: return
        if normal is not None and dot(n,normal)<0: b,c=c,b
        self.triangles.append([self.vertex(a),self.vertex(b),self.vertex(c)])
    def quad(self,a,b,c,d,normal):
        self.triangle(a,b,c,normal); self.triangle(a,c,d,normal)
    def polygon(self, points, normal):
        axis=max(range(3),key=lambda i:abs(normal[i]))
        keep=[i for i in range(3) if i!=axis]
        flat=[(p[keep[0]],p[keep[1]]) for p in points]
        for a,b,c in triangulate(flat): self.triangle(points[a],points[b],points[c],normal)

def extrude(profile, depth=1.0, axis='x', offset=None):
    """Extrude a simple profile in a unit cell; profile coordinates are (u,y)."""
    # Consecutive duplicate points can appear at zero-height ramp endpoints.
    p=[]
    for v in profile:
        if not p or v!=p[-1]: p.append(v)
    if p[0]==p[-1]: p.pop()
    area=sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(p,p[1:]+p[:1]))
    if area<0: p.reverse()
    lo=(1-depth)/2 if offset is None else offset
    hi=lo+depth
    def world(q,w): return (w,q[1],q[0]) if axis=='x' else (q[0],q[1],w)
    m=Mesh()
    low_n=(-1,0,0) if axis=='x' else (0,0,-1)
    high_n=tuple(-v for v in low_n)
    for a,b,c in triangulate(p):
        m.triangle(world(p[a],lo),world(p[b],lo),world(p[c],lo),low_n)
        m.triangle(world(p[a],hi),world(p[b],hi),world(p[c],hi),high_n)
    for a,b in zip(p,p[1:]+p[:1]):
        du,dv=b[0]-a[0],b[1]-a[1]
        n=(0,-du,dv) if axis=='x' else (dv,-du,0)
        m.quad(world(a,lo),world(b,lo),world(b,hi),world(a,hi),n)
    return m

def boxes(parts):
    """Exact union of axis-aligned boxes on their shared coordinate grid.
    Emits only union boundary faces; no overlapping internal box faces.
    """
    grids=[sorted({b[i] for b in parts}|{b[i+3] for b in parts}) for i in range(3)]
    occupied=set()
    for idx in itertools.product(*(range(len(g)-1) for g in grids)):
        p=[(grids[i][idx[i]]+grids[i][idx[i]+1])/2 for i in range(3)]
        if any(all(b[i]<p[i]<b[i+3] for i in range(3)) for b in parts): occupied.add(idx)
    m=Mesh()
    for idx in sorted(occupied):
        low=[grids[i][idx[i]] for i in range(3)]
        high=[grids[i][idx[i]+1] for i in range(3)]
        for axis in range(3):
            keep=[i for i in range(3) if i!=axis]
            for sign in (-1,1):
                neighbor=list(idx);neighbor[axis]+=sign
                if tuple(neighbor) in occupied: continue
                points=[]
                for u,v in ((0,0),(1,0),(1,1),(0,1)):
                    p=list(low);p[axis]=low[axis] if sign<0 else high[axis]
                    p[keep[0]]=high[keep[0]] if u else low[keep[0]]
                    p[keep[1]]=high[keep[1]] if v else low[keep[1]]
                    points.append(tuple(p))
                normal=[0,0,0];normal[axis]=sign
                m.quad(*points,normal)
    return m

def roof_corner(height, inner):
    m=Mesh()
    a=(0,0,0);b=(1,0,0);c=(1,0,1);d=(0,0,1)
    aa=a;bb=(1,height if inner else 0,0);cc=(1,height,1);dd=(0,height if inner else 0,1)
    m.quad(a,b,c,d,(0,-1,0))
    m.triangle(aa,bb,cc,(0,1,0));m.triangle(aa,cc,dd,(0,1,0))
    for p,q,r,s,n in ((a,b,bb,aa,(0,0,-1)),(b,c,cc,bb,(1,0,0)),(c,d,dd,cc,(0,0,1)),(d,a,aa,dd,(-1,0,0))):m.quad(p,q,r,s,n)
    return m

def pyramid(height, top=0.0):
    m=Mesh();base=[(0,0,0),(1,0,0),(1,0,1),(0,0,1)]
    m.quad(*base,(0,-1,0))
    if top==0:
        for a,b in zip(base,base[1:]+base[:1]):
            mid=tuple((x+y)/2 for x,y in zip(a,b)); n=(mid[0]-.5,.25,mid[2]-.5)
            m.triangle(a,b,(.5,height,.5),n)
    else:
        lo=(1-top)/2;hi=1-lo
        upper=[(lo,height,lo),(hi,height,lo),(hi,height,hi),(lo,height,hi)]
        m.quad(*upper,(0,1,0))
        for i in range(4):
            j=(i+1)%4; mid=tuple((x+y)/2 for x,y in zip(base[i],base[j])); n=(mid[0]-.5,.25,mid[2]-.5)
            m.quad(base[i],base[j],upper[j],upper[i],n)
    return m

def round_column(radius, segments=16, inner=0.0, height=1.0):
    m=Mesh()
    ring=[(.5+radius*math.cos(2*math.pi*i/segments),.5+radius*math.sin(2*math.pi*i/segments)) for i in range(segments)]
    inside=[(.5+inner*math.cos(2*math.pi*i/segments),.5+inner*math.sin(2*math.pi*i/segments)) for i in range(segments)]
    def p(q,y):return (q[0],y,q[1])
    for i in range(segments):
        j=(i+1)%segments;a,b=ring[i],ring[j];n=((a[0]+b[0])/2-.5,0,(a[1]+b[1])/2-.5)
        m.quad(p(a,0),p(b,0),p(b,height),p(a,height),n)
        if inner:
            c,d=inside[i],inside[j]
            m.quad(p(c,0),p(d,0),p(d,height),p(c,height),tuple(-v for v in n))
            m.quad(p(a,0),p(b,0),p(d,0),p(c,0),(0,-1,0))
            m.quad(p(a,height),p(b,height),p(d,height),p(c,height),(0,1,0))
        else:
            m.triangle((.5,0,.5),p(a,0),p(b,0),(0,-1,0))
            m.triangle((.5,height,.5),p(a,height),p(b,height),(0,1,0))
    return m

def rotations():
    result=[]
    for perm in itertools.permutations(range(3)):
        for signs in itertools.product((-1,1),repeat=3):
            rows=[[0,0,0] for _ in range(3)]
            for i in range(3):rows[i][perm[i]]=signs[i]
            if dot(rows[0],cross(rows[1],rows[2]))==1:result.append(rows)
    identity=[[1,0,0],[0,1,0],[0,0,1]]
    result.sort(key=lambda m: (m!=identity,m))
    return result

ROTATIONS=rotations()

def rotated(p,r):return tuple(round(.5+sum(r[i][j]*(p[j]-.5) for j in range(3)),7) for i in range(3))

def volume(m):return sum(dot(m.vertices[a],cross(m.vertices[b],m.vertices[c]))/6 for a,b,c in m.triangles)

def signature(m):
    """Exact triangle-soup signature in the same pose, preserving winding.
    No rotation equivalence, volume shortcut, or general CSG equivalence claim.
    """
    faces = []
    for triangle in m.triangles:
        points = tuple(tuple(m.vertices[i]) for i in triangle)
        faces.append(min(points, points[1:] + points[:1], points[2:] + points[:2]))
    return tuple(sorted(faces))

def bake(m):
    sides=[];areas=[0.0]*6
    for tri in m.triangles:
        a,b,c=[m.vertices[i] for i in tri];n=cross(sub(b,a),sub(c,a));side=-1
        for axis in range(3):
            for k,bound in enumerate((0,1)):
                sign=-1 if k==0 else 1
                if all(abs(p[axis]-bound)<EPS for p in (a,b,c)) and n[axis]*sign>0:
                    side=axis*2+k;areas[side]+=math.sqrt(dot(n,n))/2
        sides.append(side)
    full=sum(1<<i for i,v in enumerate(areas) if abs(v-1.0)<1e-6)
    return {'vertices':m.vertices,'triangles':m.triangles,'sides':sides,'full_sides':full}

# Each operation has an exact parameter schema. Unknown operations, extra keys,
# booleans in numeric fields and non-finite values are rejected, not evaluated.
SCHEMAS = {
    'cuboid': {'size', 'origin'},
    'ramp': {'height', 'width'},
    'ramp_segment': {'parts', 'part'},
    'stairs': {'steps', 'height', 'width'},
    'roof_corner': {'height', 'inner'},
    'pyramid': {'height', 'top'},
    'ridge': {'height', 'width'},
    'panel': {'rise', 'thickness', 'width'},
    'column': {'radius', 'segments', 'inner', 'height'},
    'frame': {'thickness', 'depth', 'kind'},
    'trim': {'thickness', 'depth', 'kind'},
    'arch': {'thickness', 'depth', 'height', 'segments'},
    'arched_opening': {'thickness', 'depth', 'segments'},
    'quarter_curve': {'thickness', 'depth', 'segments', 'solid'},
}


def number(value, name: str, low: float = 0.0, high: float = 1.0,
           allow_low: bool = False) -> float:
    if type(value) not in (int, float):
        raise ValueError(f'{name}: expected a finite number, not {type(value).__name__}')
    try:
        result = float(value)
    except OverflowError as error:
        raise ValueError(f'{name}: number is too large') from error
    if not math.isfinite(result) or result > high or (result < low if allow_low else result <= low):
        raise ValueError(f'{name}: outside permitted range')
    return result


def integer(value, name: str, low: int, high: int) -> int:
    if type(value) is not int or not low <= value <= high:
        raise ValueError(f'{name}: expected integer in [{low}, {high}]')
    return value


def text(value, name: str) -> str:
    if not isinstance(value, str) or not 1 <= len(value) <= 160:
        raise ValueError(f'{name}: expected nonempty text of at most 160 characters')
    if any(ord(c) < 32 for c in value):
        raise ValueError(f'{name}: control characters are not allowed')
    return value


def validate_recipe(recipe: dict) -> None:
    if not isinstance(recipe, dict) or set(recipe) != {'id', 'family', 'label', 'operation', 'parameters'}:
        raise ValueError('Recipe must have exactly id, family, label, operation, parameters')
    for key in ('id', 'family', 'label'):
        text(recipe[key], key)
    if not re.fullmatch(r'[a-z][a-z0-9._-]{0,127}', recipe['id']):
        raise ValueError('Invalid recipe ID')
    op, p = recipe['operation'], recipe['parameters']
    if not isinstance(op, str) or op not in SCHEMAS:
        raise ValueError(f'Unsupported primitive operation: {op!r}')
    if not isinstance(p, dict) or set(p) != SCHEMAS[op]:
        raise ValueError(f'{op}: unexpected or missing parameters')
    if op == 'cuboid':
        if any(not isinstance(p[k], list) or len(p[k]) != 3 for k in ('size', 'origin')):
            raise ValueError('Cuboid size/origin must be three-number lists')
        for size, origin in zip(p['size'], p['origin']):
            a = number(size, 'size')
            b = number(origin, 'origin', allow_low=True)
            if a + b > 1.0 + EPS:
                raise ValueError('Cuboid extends beyond its unit cell')
        return
    for key in ('height', 'width', 'depth', 'rise'):
        if key in p:
            number(p[key], key)
    if 'thickness' in p:
        number(p['thickness'], 'thickness')
    if 'segments' in p:
        integer(p['segments'], 'segments', 3, 64)
    if op == 'ramp_segment':
        parts = integer(p['parts'], 'parts', 2, 64)
        integer(p['part'], 'part', 1, parts)
    elif op == 'stairs':
        integer(p['steps'], 'steps', 1, 32)
    elif op == 'roof_corner':
        if type(p['inner']) is not bool:
            raise ValueError('inner must be a boolean')
    elif op == 'pyramid':
        number(p['top'], 'top', allow_low=True)
    elif op == 'panel':
        if p['rise'] + p['thickness'] > 1.0 + EPS:
            raise ValueError('Panel rise plus thickness exceeds the unit cell')
    elif op == 'column':
        radius = number(p['radius'], 'radius', high=0.5)
        inner = number(p['inner'], 'inner', high=0.5, allow_low=True)
        if inner >= radius:
            raise ValueError('Column inner radius must be less than its outer radius')
    elif op in ('frame', 'trim', 'arch', 'arched_opening'):
        if p['thickness'] >= 0.5:
            raise ValueError('Opening/trim thickness must be less than half a cell')
        if op == 'frame' and p['kind'] not in ('door', 'window'):
            raise ValueError('Unknown frame kind')
        if op == 'trim' and p['kind'] not in ('corner', 'cross'):
            raise ValueError('Unknown trim kind')
    elif op == 'quarter_curve':
        if type(p['solid']) is not bool:
            raise ValueError('solid must be a boolean')
        if p['solid'] and p['thickness'] != 1.0:
            raise ValueError('Solid quarter curve uses thickness 1')
        if not p['solid'] and p['thickness'] >= 1.0:
            raise ValueError('Curved trim must retain a positive inner radius')


def mesh_from_recipe(recipe: dict) -> Mesh:
    """Turn an explicitly validated primitive recipe into a closed mesh."""
    validate_recipe(recipe)
    op, p = recipe['operation'], recipe['parameters']
    if op == 'cuboid':
        lo = p['origin']
        hi = [a + b for a, b in zip(lo, p['size'])]
        return boxes([tuple(lo + hi)])
    if op == 'ramp':
        return extrude([(0, 0), (1, 0), (1, p['height'])], p['width'])
    if op == 'ramp_segment':
        count, part = p['parts'], p['part']
        return extrude([(0, 0), (1, 0), (1, part/count), (0, (part-1)/count)])
    if op == 'stairs':
        count, h = p['steps'], p['height']
        profile = [(0, 0), (1, 0), (1, h)]
        for i in range(count - 1, -1, -1):
            profile.append((i/count, (i+1)*h/count))
            if i > 0:
                profile.append((i/count, i*h/count))
        return extrude(profile, p['width'])
    if op == 'roof_corner':
        return roof_corner(p['height'], p['inner'])
    if op == 'pyramid':
        return pyramid(p['height'], p['top'])
    if op == 'ridge':
        return extrude([(0, 0), (1, 0), (0.5, p['height'])], p['width'], 'z')
    if op == 'panel':
        rise, t = p['rise'], p['thickness']
        return extrude([(0, 0), (1, rise), (1, rise+t), (0, t)], p['width'])
    if op == 'column':
        return round_column(p['radius'], p['segments'], p['inner'], p['height'])
    if op in ('frame', 'trim'):
        t, d = p['thickness'], p['depth']
        z = (1-d)/2
        if op == 'frame':
            parts = [(0, 0, z, t, 1, z+d), (1-t, 0, z, 1, 1, z+d), (t, 1-t, z, 1-t, 1, z+d)]
            if p['kind'] == 'window':
                parts.append((t, 0, z, 1-t, t, z+d))
        elif p['kind'] == 'corner':
            parts = [(0, 0, z, t, 1, z+d), (t, 0, z, 1, t, z+d)]
        else:
            lo, hi = (1-t)/2, (1+t)/2
            parts = [(lo, 0, z, hi, 1, z+d), (0, lo, z, 1, hi, z+d)]
        return boxes(parts)
    if op == 'arch':
        t, h, n = p['thickness'], p['height'], p['segments']
        ro, ri = 0.5, 0.5-t
        profile = [(0.5+ro*math.cos(math.pi*i/n), h*math.sin(math.pi*i/n)) for i in range(n+1)]
        profile += [(0.5+ri*math.cos(math.pi*i/n), h*(ri/ro)*math.sin(math.pi*i/n)) for i in range(n, -1, -1)]
        return extrude(profile, p['depth'], 'z')
    if op == 'arched_opening':
        t, n = p['thickness'], p['segments']
        r = 0.5-t
        profile = [(0, 0), (t, 0), (t, 0.5)]
        profile += [(0.5+r*math.cos(math.pi*(1-i/n)), 0.5+r*math.sin(math.pi*(1-i/n))) for i in range(1, n+1)]
        profile += [(1-t, 0), (1, 0), (1, 1), (0, 1)]
        return extrude(profile, p['depth'], 'z')
    # Quarter ellipse/circle is the only remaining whitelisted operation.
    t, n = p['thickness'], p['segments']
    arc = [(math.cos(math.pi*i/(2*n)), math.sin(math.pi*i/(2*n))) for i in range(n+1)]
    profile = [(0, 0)] + arc if p['solid'] else arc + [((1-t)*x, (1-t)*y) for x, y in reversed(arc)]
    return extrude(profile, p['depth'], 'z')


def canonical_json(value) -> bytes:
    return (json.dumps(value, separators=(',', ':'), ensure_ascii=True, allow_nan=False) + '\n').encode('utf-8')


def build_catalogue(spec: dict, source_bytes: bytes) -> dict:
    if not isinstance(spec, dict) or set(spec) != {'format', 'license', 'description', 'coordinate_system', 'shapes', 'aliases'}:
        raise ValueError('Unexpected recipe document fields')
    if type(spec['format']) is not int or spec['format'] != 1 or spec['license'] != 'CC0-1.0':
        raise ValueError('Expected recipe format 1 and CC0-1.0 data')
    if not isinstance(spec['shapes'], list) or not 1 <= len(spec['shapes']) <= 4096:
        raise ValueError('Expected between 1 and 4096 shape recipes')
    if not isinstance(spec['aliases'], list) or len(spec['aliases']) > 4096:
        raise ValueError('Invalid alias list')
    if not isinstance(spec['description'], str) or not isinstance(spec['coordinate_system'], str):
        raise ValueError('Recipe description and coordinate system must be strings')
    if any(len(spec[k]) > 2048 or any(ord(c) < 32 for c in spec[k]) for k in ('description', 'coordinate_system')):
        raise ValueError('Invalid recipe metadata text')
    shapes, meshes, aliases = [], {}, {}
    for recipe in spec['shapes']:
        mesh = mesh_from_recipe(recipe)
        key = recipe['id']
        if key in meshes:
            raise ValueError(f'Duplicate shape ID: {key}')
        meshes[key] = mesh
        shapes.append({
            'id': key, 'family': recipe['family'], 'label': recipe['label'],
            'operation': recipe['operation'], 'parameters': recipe['parameters'],
            'recipe_sha256': hashlib.sha256(canonical_json(recipe)).hexdigest(), **bake(mesh),
        })
    for alias in spec['aliases']:
        if not isinstance(alias, dict) or set(alias) != {'id', 'target', 'recipe', 'condition'}:
            raise ValueError('Unexpected alias fields')
        key, target = alias['id'], alias['target']
        if not isinstance(key, str) or not isinstance(target, str) or key in meshes or key in aliases or target not in meshes:
            raise ValueError('Alias ID/target is missing, duplicated, recursive or invalid')
        if alias['condition'] != 'same_pose_oriented_triangles' or not isinstance(alias['recipe'], dict) or alias['recipe'].get('id') != key:
            raise ValueError('Alias condition or recipe ID mismatch')
        candidate = mesh_from_recipe(alias['recipe'])
        if signature(candidate) != signature(meshes[target]):
            raise ValueError(f'Alias {key} changes triangle geometry, pose or winding')
        aliases[key] = target
    return {
        'format': 2, 'license': 'CC0-1.0', 'unit': 'unit cell [0,1]^3',
        'winding': 'counter-clockwise outward',
        'side_order': ['-X', '+X', '-Y', '+Y', '-Z', '+Z'],
        'recipe_source_sha256': hashlib.sha256(source_bytes).hexdigest(),
        'rotations': ROTATIONS, 'shapes': shapes, 'aliases': aliases,
        'deduplicated_candidates': list(aliases),
    }


def load_spec(path: Path) -> tuple[dict, bytes]:
    if path.stat().st_size > 16 * 1024 * 1024:
        raise ValueError('Recipe file exceeds 16 MiB safety limit')
    raw = path.read_bytes()
    def reject_constant(value):
        raise ValueError(f'Non-finite JSON token: {value}')
    def unique_object(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f'Duplicate JSON field: {key}')
            result[key] = value
        return result
    return json.loads(raw, parse_constant=reject_constant, object_pairs_hook=unique_object), raw


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=ROOT, help='Output directory; default is the addon directory')
    args = parser.parse_args()
    try:
        spec, raw = load_spec(ROOT / 'recipes.json')
        data = build_catalogue(spec, raw)
        args.out.mkdir(parents=True, exist_ok=True)
        output = args.out / 'catalogue.json'
        output.write_bytes(canonical_json(data))
        print(f'Built {len(data["shapes"])} meshes, {len(data["aliases"])} exact-pose aliases, 24 rotations')
        print(f'SHA256 {hashlib.sha256(output.read_bytes()).hexdigest()}  catalogue.json')
        return 0
    except (OSError, ValueError, TypeError, KeyError) as error:
        print(f'Build failed: {error}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
