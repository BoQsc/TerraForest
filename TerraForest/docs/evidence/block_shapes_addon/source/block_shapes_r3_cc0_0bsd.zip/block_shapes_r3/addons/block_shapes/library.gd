# SPDX-License-Identifier: 0BSD
@tool
extends RefCounted
## Adapter for CC0 numeric data. Project r1 ancestry is recorded in ORIGIN.md.
## Catalogue triangles are CCW; this adapter reverses them for Godot's CW fronts.

const CATALOGUE_PATH := "res://addons/block_shapes/catalogue.json"
const DIRECTIONS = [Vector3i(-1, 0, 0), Vector3i(1, 0, 0), Vector3i(0, -1, 0), Vector3i(0, 1, 0), Vector3i(0, 0, -1), Vector3i(0, 0, 1)]
var shapes: Array = []
var last_error: String = ""
var _catalogue: Dictionary = {}
var rotations: Array[Basis] = []
var default_material: StandardMaterial3D
var _by_id: Dictionary = {}
var _prepared: Dictionary = {}

func _init() -> void:
	default_material = StandardMaterial3D.new()
	default_material.albedo_color = Color(0.72, 0.76, 0.8)
	default_material.roughness = 0.88
	var file := FileAccess.open(CATALOGUE_PATH, FileAccess.READ)
	if file == null:
		_fail("Catalogue missing. Enable the plugin for exports or include addons/block_shapes/catalogue.json in the export filter.")
		return
	if file.get_length() > 16777216:
		_fail("Catalogue exceeds the 16 MiB safety limit.")
		return
	var parser := JSON.new()
	if parser.parse(file.get_as_text()) != OK or not valid_catalogue(parser.data):
		_fail("Invalid catalogue data.")
		return
	_catalogue = parser.data
	shapes = _catalogue["shapes"]
	for i in range(shapes.size()):
		_by_id[String(shapes[i]["id"])] = i
	for alias in _catalogue["aliases"]:
		_by_id[alias] = _by_id[_catalogue["aliases"][alias]]
	for rows in _catalogue["rotations"]:
		rotations.append(Basis(
			Vector3(rows[0][0], rows[1][0], rows[2][0]),
			Vector3(rows[0][1], rows[1][1], rows[2][1]),
			Vector3(rows[0][2], rows[1][2], rows[2][2])))

func _fail(message: String) -> void:
	last_error = message
	push_error("Block Shapes: " + message)

static func _number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))

static func _integer(value: Variant, minimum: int, maximum: int) -> bool:
	if not _number(value):
		return false
	var numeric := float(value)
	return numeric == floor(numeric) and numeric >= minimum and numeric <= maximum

static func valid_catalogue(value: Variant) -> bool:
	# JSON is data only. Do not execute it or load user-named scripts/resources.
	if not value is Dictionary:
		return false
	if not _integer(value.get("format"), 2, 2) or value.get("license") != "CC0-1.0":
		return false
	if not value.get("shapes") is Array or not value.get("rotations") is Array or not value.get("aliases") is Dictionary:
		return false
	if value["shapes"].is_empty() or value["shapes"].size() > 4096 or value["rotations"].size() != 24:
		return false
	var identifiers: Dictionary = {}
	for shape in value["shapes"]:
		if not shape is Dictionary or not shape.get("id") is String or not shape.get("label") is String or not shape.get("family") is String:
			return false
		if shape["id"].is_empty() or identifiers.has(shape["id"]):
			return false
		identifiers[shape["id"]] = true
		if not shape.get("vertices") is Array or not shape.get("triangles") is Array or not shape.get("sides") is Array:
			return false
		if shape["vertices"].size() < 4 or shape["vertices"].size() > 4096 or shape["triangles"].is_empty() or shape["triangles"].size() > 8192:
			return false
		if shape["sides"].size() != shape["triangles"].size() or not _integer(shape.get("full_sides"), 0, 63):
			return false
		for point in shape["vertices"]:
			if not point is Array or point.size() != 3:
				return false
			for component in point:
				if not _number(component) or float(component) < -0.000001 or float(component) > 1.000001:
					return false
		for triangle in shape["triangles"]:
			if not triangle is Array or triangle.size() != 3:
				return false
			for index in triangle:
				if not _integer(index, 0, shape["vertices"].size() - 1):
					return false
			if triangle[0] == triangle[1] or triangle[1] == triangle[2] or triangle[2] == triangle[0]:
				return false
		for side in shape["sides"]:
			if not _integer(side, -1, 5):
				return false
	for alias in value["aliases"]:
		if not alias is String or identifiers.has(alias) or not value["aliases"][alias] is String or not identifiers.has(value["aliases"][alias]):
			return false
	var bases: Array[Basis] = []
	for rows in value["rotations"]:
		if not rows is Array or rows.size() != 3:
			return false
		for row in rows:
			if not row is Array or row.size() != 3:
				return false
			for component in row:
				if not _integer(component, -1, 1):
					return false
		var basis := Basis(Vector3(rows[0][0], rows[1][0], rows[2][0]), Vector3(rows[0][1], rows[1][1], rows[2][1]), Vector3(rows[0][2], rows[1][2], rows[2][2]))
		if not is_equal_approx(basis.determinant(), 1.0) or not (basis.transposed() * basis).is_equal_approx(Basis.IDENTITY):
			return false
		for existing in bases:
			if existing.is_equal_approx(basis):
				return false
		bases.append(basis)
	return bases[0].is_equal_approx(Basis.IDENTITY)

func find_shape(id: String) -> int:
	return int(_by_id.get(id, -1))

func find_orientation(basis: Basis) -> int:
	for i in range(rotations.size()):
		if rotations[i].is_equal_approx(basis):
			return i
	return -1

func side_from_direction(direction: Vector3) -> int:
	var a := direction.abs()
	if a.x >= a.y and a.x >= a.z:
		return 1 if direction.x > 0.0 else 0
	if a.y >= a.z:
		return 3 if direction.y > 0.0 else 2
	return 5 if direction.z > 0.0 else 4

func _rotate_side(side: int, basis: Basis) -> int:
	return side_from_direction(basis * Vector3(DIRECTIONS[side]))

func _uv(p: Vector3, normal: Vector3) -> Vector2:
	var a := normal.abs()
	if a.y >= a.x and a.y >= a.z:
		return Vector2(p.x, p.z)
	if a.x >= a.z:
		return Vector2(p.z, 1.0 - p.y)
	return Vector2(p.x, 1.0 - p.y)

func prepared(shape_index: int, orientation: int = 0) -> Dictionary:
	if shape_index < 0 or shape_index >= shapes.size():
		push_error("Block Shapes: invalid shape index %s" % shape_index)
		return {}
	orientation = posmod(orientation, 24)
	var key := shape_index * 24 + orientation
	if _prepared.has(key):
		return _prepared[key]
	var shape: Dictionary = shapes[shape_index]
	var basis: Basis = rotations[orientation]
	var source: Array = shape["vertices"]
	var vertices := PackedVector3Array()
	var normals := PackedVector3Array()
	var uvs := PackedVector2Array()
	var sides := PackedInt32Array()
	for tri_index in range(shape["triangles"].size()):
		var triangle: Array = shape["triangles"][tri_index]
		var a := Vector3(source[int(triangle[0])][0], source[int(triangle[0])][1], source[int(triangle[0])][2])
		var b := Vector3(source[int(triangle[1])][0], source[int(triangle[1])][1], source[int(triangle[1])][2])
		var c := Vector3(source[int(triangle[2])][0], source[int(triangle[2])][1], source[int(triangle[2])][2])
		var n := (b - a).cross(c - a).normalized()
		# Godot's front-facing triangles have clockwise vertex order.
		for p in [a, c, b]:
			vertices.append(basis * (p - Vector3.ONE * 0.5) + Vector3.ONE * 0.5)
			normals.append(basis * n)
			uvs.append(_uv(p, n))
		var side := int(shape["sides"][tri_index])
		sides.append(_rotate_side(side, basis) if side >= 0 else -1)
	var full_sides := 0
	for side in range(6):
		if int(shape["full_sides"]) & (1 << side):
			full_sides |= 1 << _rotate_side(side, basis)
	var result := {"vertices": vertices, "normals": normals, "uvs": uvs, "sides": sides, "full_sides": full_sides}
	_prepared[key] = result
	return result

func create_mesh(shape_index: int, orientation: int = 0, material: Material = null) -> ArrayMesh:
	var data := prepared(shape_index, orientation)
	var mesh := ArrayMesh.new()
	if data.is_empty():
		return mesh
	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = data["vertices"]
	arrays[Mesh.ARRAY_NORMAL] = data["normals"]
	arrays[Mesh.ARRAY_TEX_UV] = data["uvs"]
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	mesh.surface_set_material(0, material if material != null else default_material)
	return mesh

func create_collision(shape_index: int, orientation: int = 0) -> ConcavePolygonShape3D:
	var data := prepared(shape_index, orientation)
	var result := ConcavePolygonShape3D.new()
	if not data.is_empty():
		result.set_faces(data["vertices"])
	return result

func create_mesh_library() -> MeshLibrary:
	var result := MeshLibrary.new()
	# GridMap centers cells by default. Center each catalogue item around origin.
	var centered := Transform3D(Basis.IDENTITY, -Vector3.ONE * 0.5)
	for i in range(shapes.size()):
		result.create_item(i)
		result.set_item_name(i, String(shapes[i]["label"]))
		result.set_item_mesh(i, create_mesh(i))
		result.set_item_mesh_transform(i, centered)
		result.set_item_shapes(i, [create_collision(i), centered])
	return result
