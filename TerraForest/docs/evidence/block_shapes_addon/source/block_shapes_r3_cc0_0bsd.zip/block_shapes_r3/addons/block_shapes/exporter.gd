# SPDX-License-Identifier: 0BSD
@tool
extends EditorExportPlugin
## Packs only the numeric runtime catalogue; source recipes remain in source distributions.
const CATALOGUE := "res://addons/block_shapes/catalogue.json"

func _get_name() -> String:
	return "BlockShapesCatalogue"

func _export_begin(_features: PackedStringArray, _is_debug: bool, _path: String, _flags: int) -> void:
	var bytes := FileAccess.get_file_as_bytes(CATALOGUE)
	if bytes.is_empty():
		push_error("Block Shapes: cannot pack catalogue.json")
		return
	add_file(CATALOGUE, bytes, false)
