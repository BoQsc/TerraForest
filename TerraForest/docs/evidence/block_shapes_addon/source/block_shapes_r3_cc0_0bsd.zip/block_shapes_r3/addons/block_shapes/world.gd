# SPDX-License-Identifier: 0BSD
extends Node3D
## Sparse editable construction world. A prototype, not a streaming terrain engine.
## All geometry is batched by chunk and material; no individual nodes per block.
## Change chunk_size or cell_size only while the world is empty.

const MAX_BLOCKS := 1000000
const MAX_MATERIALS := 256
const MAX_COORDINATE := 100000000
const MAX_SAVE_BYTES := 67108864
const Library = preload("res://addons/block_shapes/library.gd")
@export_range(4, 32, 1) var chunk_size: int = 16
@export_range(0.01, 100.0, 0.01) var cell_size: float = 1.0
@export_range(1, 16, 1) var chunks_per_frame: int = 1
@export var collision_enabled: bool = true
@export var materials: Array[Material] = []
## Mark transparent/cutout material slots here so they never hide adjacent faces.
@export var non_occluding_materials: PackedInt32Array = PackedInt32Array()
var library = Library.new()
var _cells: Dictionary = {}
var _chunk_cells: Dictionary = {}
var _dirty: Dictionary = {}
var _nodes: Dictionary = {}
var _triangles: Dictionary = {}

func _process(_delta: float) -> void:
	rebuild_dirty(chunks_per_frame)

func _chunk_of(cell: Vector3i) -> Vector3i:
	return Vector3i(floori(float(cell.x) / chunk_size), floori(float(cell.y) / chunk_size), floori(float(cell.z) / chunk_size))

func _mark_changed(cell: Vector3i) -> void:
	_dirty[_chunk_of(cell)] = true
	for direction in Library.DIRECTIONS:
		var neighbor_chunk := _chunk_of(cell + direction)
		if _chunk_cells.has(neighbor_chunk):
			_dirty[neighbor_chunk] = true

func set_block(cell: Vector3i, shape_id: String, orientation: int = 0, material: int = 0) -> bool:
	var shape_index: int = library.find_shape(shape_id)
	if shape_index < 0:
		push_error("Block Shapes: unknown shape id: " + shape_id)
		return false
	return set_block_index(cell, shape_index, orientation, material)

func set_block_index(cell: Vector3i, shape_index: int, orientation: int = 0, material: int = 0) -> bool:
	if shape_index < 0 or shape_index >= library.shapes.size() or material < 0 or material >= MAX_MATERIALS:
		return false
	if chunk_size < 4 or chunk_size > 32 or not is_finite(cell_size) or cell_size < 0.01 or cell_size > 100.0:
		return false
	if absi(cell.x) > MAX_COORDINATE or absi(cell.y) > MAX_COORDINATE or absi(cell.z) > MAX_COORDINATE:
		return false
	if not _cells.has(cell) and _cells.size() >= MAX_BLOCKS:
		return false
	var value := Vector3i(shape_index, posmod(orientation, 24), material)
	if _cells.has(cell) and _cells[cell] == value:
		return true
	_cells[cell] = value
	var chunk := _chunk_of(cell)
	if not _chunk_cells.has(chunk):
		_chunk_cells[chunk] = {}
	_chunk_cells[chunk][cell] = true
	_mark_changed(cell)
	return true

func remove_block(cell: Vector3i) -> bool:
	if not _cells.has(cell):
		return false
	_cells.erase(cell)
	var chunk := _chunk_of(cell)
	_chunk_cells[chunk].erase(cell)
	_mark_changed(cell)
	return true

func has_block(cell: Vector3i) -> bool:
	return _cells.has(cell)

func get_block(cell: Vector3i) -> Dictionary:
	if not _cells.has(cell):
		return {}
	var value: Vector3i = _cells[cell]
	return {"shape_id": library.shapes[value.x]["id"], "shape_index": value.x, "orientation": value.y, "material": value.z}

func _retire(node: Node) -> void:
	# Remove immediately so repeated edits in one frame cannot leave stale bodies.
	if node.get_parent() != null:
		node.get_parent().remove_child(node)
	node.queue_free()

func refresh_all() -> void:
	# Call after changing materials, occlusion slots, or collision_enabled.
	for chunk in _chunk_cells:
		_dirty[chunk] = true

func clear() -> void:
	for node in _nodes.values():
		_retire(node)
	_cells.clear()
	_chunk_cells.clear()
	_dirty.clear()
	_nodes.clear()
	_triangles.clear()

func flush() -> void:
	# Explicit synchronous build for loading/tests. Large worlds can stall here.
	rebuild_dirty(_dirty.size())

func rebuild_dirty(limit: int = 1) -> void:
	var pending: Array = _dirty.keys()
	for i in range(mini(limit, pending.size())):
		var chunk: Vector3i = pending[i]
		_dirty.erase(chunk)
		_rebuild_chunk(chunk)

func _material(index: int) -> Material:
	if index < materials.size() and materials[index] != null:
		return materials[index]
	return library.default_material

func _rebuild_chunk(chunk: Vector3i) -> void:
	var members: Dictionary = _chunk_cells.get(chunk, {})
	if members.is_empty():
		if _nodes.has(chunk):
			_retire(_nodes[chunk])
			_nodes.erase(chunk)
		_chunk_cells.erase(chunk)
		_triangles.erase(chunk)
		return
	var buckets: Dictionary = {}
	var all_collision := PackedVector3Array()
	var origin: Vector3i = chunk * chunk_size
	var count := 0
	for cell in members:
		var value: Vector3i = _cells[cell]
		var data: Dictionary = library.prepared(value.x, value.y)
		# Six neighbor masks are computed once per block, not for every triangle.
		var hidden := 0
		for side in range(6):
			var neighbor: Vector3i = cell + Library.DIRECTIONS[side]
			if not _cells.has(neighbor):
				continue
			var other: Vector3i = _cells[neighbor]
			if non_occluding_materials.has(other.z):
				continue
			var other_data: Dictionary = library.prepared(other.x, other.y)
			if int(other_data["full_sides"]) & (1 << (side ^ 1)):
				hidden |= 1 << side
		if not buckets.has(value.z):
			buckets[value.z] = {"vertices": PackedVector3Array(), "normals": PackedVector3Array(), "uvs": PackedVector2Array()}
		var bucket: Dictionary = buckets[value.z]
		var vertices: PackedVector3Array = bucket["vertices"]
		var normals: PackedVector3Array = bucket["normals"]
		var uvs: PackedVector2Array = bucket["uvs"]
		var offset := Vector3(cell - origin)
		for tri in range(data["sides"].size()):
			var side: int = data["sides"][tri]
			if side >= 0 and (hidden & (1 << side)):
				continue
			count += 1
			for k in range(3):
				var index := tri * 3 + k
				var vertex: Vector3 = (data["vertices"][index] + offset) * cell_size
				vertices.append(vertex)
				normals.append(data["normals"][index])
				uvs.append(data["uvs"][index])
				if collision_enabled:
					all_collision.append(vertex)
		bucket["vertices"] = vertices
		bucket["normals"] = normals
		bucket["uvs"] = uvs
	var mesh := ArrayMesh.new()
	var material_ids: Array = buckets.keys()
	material_ids.sort()
	for material_id in material_ids:
		var bucket: Dictionary = buckets[material_id]
		if bucket["vertices"].is_empty():
			continue
		var arrays: Array = []
		arrays.resize(Mesh.ARRAY_MAX)
		arrays[Mesh.ARRAY_VERTEX] = bucket["vertices"]
		arrays[Mesh.ARRAY_NORMAL] = bucket["normals"]
		arrays[Mesh.ARRAY_TEX_UV] = bucket["uvs"]
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
		mesh.surface_set_material(mesh.get_surface_count() - 1, _material(material_id))
	var instance: MeshInstance3D
	if _nodes.has(chunk):
		instance = _nodes[chunk]
	else:
		instance = MeshInstance3D.new()
		instance.name = "Chunk_%s_%s_%s" % [chunk.x, chunk.y, chunk.z]
		add_child(instance)
		_nodes[chunk] = instance
	instance.position = Vector3(origin) * cell_size
	instance.mesh = mesh if mesh.get_surface_count() > 0 else null
	var body: StaticBody3D = instance.get_node_or_null("Collision")
	if collision_enabled and not all_collision.is_empty():
		if body == null:
			body = StaticBody3D.new()
			body.name = "Collision"
			instance.add_child(body)
			var collision_node := CollisionShape3D.new()
			collision_node.name = "Shape"
			body.add_child(collision_node)
		var shape := ConcavePolygonShape3D.new()
		shape.set_faces(all_collision)
		var collision_node := body.get_node("Shape") as CollisionShape3D
		collision_node.shape = shape
	elif body != null:
		_retire(body)
	_triangles[chunk] = count

func statistics() -> Dictionary:
	var total := 0
	for n in _triangles.values():
		total += int(n)
	return {"blocks": _cells.size(), "chunks": _nodes.size(), "triangles": total, "dirty_chunks": _dirty.size()}

func save_world(path: String) -> bool:
	var records: Array = []
	var positions: Array = _cells.keys()
	positions.sort_custom(func(a: Vector3i, b: Vector3i) -> bool:
		if a.x != b.x: return a.x < b.x
		if a.y != b.y: return a.y < b.y
		return a.z < b.z)
	for position in positions:
		var value: Vector3i = _cells[position]
		records.append([position.x, position.y, position.z, library.shapes[value.x]["id"], value.y, value.z])
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		push_error("Block Shapes: cannot write " + path)
		return false
	file.store_string(JSON.stringify({"format": 1, "cell_size": cell_size, "chunk_size": chunk_size, "blocks": records}))
	return true

func _integer_value(value: Variant, low: int, high: int) -> bool:
	if not (value is float or value is int):
		return false
	var numeric := float(value)
	return is_finite(numeric) and numeric == floor(numeric) and numeric >= low and numeric <= high

func load_world(path: String) -> bool:
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null or file.get_length() > MAX_SAVE_BYTES:
		return false
	var parser := JSON.new()
	if parser.parse(file.get_as_text()) != OK:
		return false
	var parsed: Variant = parser.data
	if not parsed is Dictionary or not _integer_value(parsed.get("format"), 1, 1) or not parsed.get("blocks") is Array:
		return false
	if parsed["blocks"].size() > MAX_BLOCKS:
		return false
	var raw_size: Variant = parsed.get("cell_size")
	if not (raw_size is int or raw_size is float):
		return false
	var size_value := float(raw_size)
	if not is_finite(size_value) or size_value < 0.01 or size_value > 100.0:
		return false
	if not _integer_value(parsed.get("chunk_size"), 4, 32):
		return false
	var chunk_value := int(parsed["chunk_size"])
	# Validate every record and duplicate position before replacing the live world.
	var validated: Array = []
	var seen: Dictionary = {}
	for row in parsed["blocks"]:
		if not row is Array or row.size() != 6 or not row[3] is String:
			return false
		for field in [0, 1, 2]:
			if not _integer_value(row[field], -MAX_COORDINATE, MAX_COORDINATE):
				return false
		if not _integer_value(row[4], 0, 23) or not _integer_value(row[5], 0, MAX_MATERIALS - 1):
			return false
		var index: int = library.find_shape(row[3])
		if index < 0:
			return false
		var position := Vector3i(int(row[0]), int(row[1]), int(row[2]))
		if seen.has(position):
			return false
		seen[position] = true
		validated.append([position, index, int(row[4]), int(row[5])])
	clear()
	cell_size = size_value
	chunk_size = chunk_value
	for row in validated:
		set_block_index(row[0], row[1], row[2], row[3])
	return true
