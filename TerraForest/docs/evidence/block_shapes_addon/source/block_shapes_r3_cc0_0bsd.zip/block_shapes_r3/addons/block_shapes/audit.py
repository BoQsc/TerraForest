# SPDX-License-Identifier: 0BSD
"""Check declared licence scope and source dependencies. Standard library only.
This is a static package-policy check, not a copyright-similarity detector.
Run from either distribution: python addons/block_shapes/audit.py --root .
Or inside the standalone addon: python audit.py
"""
from __future__ import annotations
import argparse
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

CODE = {'.py', '.gd', '.cfg', '.godot', '.tscn', '.bat', '.sh'}
CONTENT = {'.md', '.json', '.txt', '.svg'}
LEGAL_HASHES = {
    '0BSD': '0db3336be1d50c18d8d0f844a996cdddaf66a018dbdee58ab94933c1c6ffc2e9',
    'CC0-1.0': 'a2010f343487d3f7618affe54f789f5487602331c0a8d03f49e9a7c547cf0499',
}
STDLIB = {
    '__future__', 'argparse', 'ast', 'collections', 'contextlib', 'copy',
    'hashlib', 'html', 'importlib', 'io', 'itertools', 'json', 'math', 'os',
    'pathlib', 're', 'shlex', 'shutil', 'stat', 'subprocess', 'sys', 'tempfile',
    'time', 'unittest', 'xml', 'zipfile',
}
LOCAL_MODULES = {'generate', 'build'}


def gd_code(source: str) -> tuple[str, str]:
    """Discard comments; additionally mask string literals in the second view.
    Only lexical inspection is done here; Godot must still parse the scripts.
    """
    kept, masked = [], []
    i = 0
    while i < len(source):
        char = source[i]
        if char == '#':
            end = source.find('\n', i)
            if end < 0: end = len(source)
            kept.append(' ' * (end-i)); masked.append(' ' * (end-i)); i = end
        elif char in ('"', "'"):
            quote = char * 3 if source.startswith(char * 3, i) else char
            start = i; i += len(quote)
            while i < len(source):
                if source[i] == '\\': i += 2; continue
                if source.startswith(quote, i): i += len(quote); break
                i += 1
            else:
                raise ValueError('Unclosed GDScript string')
            literal = source[start:i]
            kept.append(literal)
            masked.append(''.join('\n' if c == '\n' else ' ' for c in literal))
        else:
            kept.append(char); masked.append(char); i += 1
    return ''.join(kept), ''.join(masked)


def check_python(source: str, relative: str, root: Path) -> set[str]:
    modules = set()
    tree = ast.parse(source, filename=relative)
    for node in ast.walk(tree):
        names = []
        if isinstance(node, ast.Import): names = [a.name.split('.')[0] for a in node.names]
        elif isinstance(node, ast.ImportFrom):
            if node.level: raise ValueError(f'{relative}: relative Python import requires review')
            names = [(node.module or '').split('.')[0]]
        for module in names:
            if module in STDLIB:
                modules.add(module)
                continue
            if module in LOCAL_MODULES and any((root / p).is_file() for p in
                    (f'tools/{module}.py', f'addons/block_shapes/{module}.py', f'{module}.py')):
                modules.add('project:' + module)
                continue
            raise ValueError(f'{relative}: unapproved Python import {module!r}')
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in {'eval','exec','compile','__import__'}:
            raise ValueError(f'{relative}: dynamic Python execution requires review')
    return modules


def check_gd(source: str, relative: str, root: Path, full: bool) -> set[str]:
    code, masked = gd_code(source)
    forbidden = r'\b(?:HTTPRequest|HTTPClient|WebSocketPeer|StreamPeerTCP|TCPServer|ENetMultiplayerPeer|GDExtensionManager|Expression)\b|\bOS\s*\.\s*(?:execute|create_process|shell_open)\s*\(|\bGDScript\s*\.\s*new\s*\(|\b(?:set_source_code|load_threaded_request)\s*\('
    if re.search(forbidden, masked):
        raise ValueError(f'{relative}: external/dynamic runtime capability requires review')
    resources = set()
    for match in re.finditer(r'\b(?:preload|load)\s*\(', masked):
        tail = code[match.end():]
        literal = re.match(r'\s*([\'"])([^\'"\n]*)\1\s*\)', tail)
        if literal is None:
            raise ValueError(f'{relative}: resource load must be a literal project path')
        resource = literal.group(2)
        if not resource.startswith('res://addons/block_shapes/'):
            raise ValueError(f'{relative}: resource dependency outside this addon: {resource}')
        local = resource.removeprefix('res://') if full else resource.removeprefix('res://addons/block_shapes/')
        target = root / local
        if '..' in Path(local).parts or not target.is_file():
            raise ValueError(f'{relative}: missing/escaping resource dependency: {resource}')
        resources.add(resource)
    return resources


def check_svg(source: str, relative: str) -> None:
    if '<!DOCTYPE' in source.upper() or '<!ENTITY' in source.upper():
        raise ValueError(f'{relative}: external/entity SVG declarations are not accepted')
    tree = ET.fromstring(source)
    for node in tree.iter():
        tag = node.tag.rsplit('}', 1)[-1]
        if tag not in {'svg','metadata','rect','g','text','polygon','path','line','polyline','circle','ellipse','title','desc'}:
            raise ValueError(f'{relative}: unsupported SVG element: {tag}')
        for key, value in node.attrib.items():
            if key.rsplit('}',1)[-1] in {'href', 'src'} or 'url(' in value.lower():
                raise ValueError(f'{relative}: linked/embedded SVG asset is not accepted')


def audit(root: Path, check_integrity: bool = True) -> dict:
    root = root.resolve()
    full = (root / 'addons/block_shapes').is_dir()
    addon = root / 'addons/block_shapes' if full else root
    if check_integrity:
        spec = importlib.util.spec_from_file_location('block_shapes_inventory', addon / 'verify.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        module.verify_manifest(root)
    entries = json.loads((root / 'MANIFEST.json').read_text(encoding='utf-8'))['files']
    counts = {'software_0bsd': 0, 'content_cc0': 1, 'standard_legal_texts': 0}
    imports, resources = set(), set()
    for relative, entry in sorted(entries.items()):
        path = root / relative
        if not path.is_file() or path.is_symlink():
            raise ValueError(f'{relative}: missing file or symlink')
        if entry.get('kind') == 'standard_license_text':
            reference = entry.get('license_reference')
            if reference not in LEGAL_HASHES or hashlib.sha256(path.read_bytes()).hexdigest() != LEGAL_HASHES[reference]:
                raise ValueError(f'{relative}: legal text differs from the reviewed standard text')
            counts['standard_legal_texts'] += 1
            continue
        expected = '0BSD' if path.suffix in CODE else 'CC0-1.0'
        if path.suffix not in CODE | CONTENT:
            raise ValueError(f'{relative}: binary/asset/file type not admitted to this source distribution')
        if entry.get('license_id') != expected:
            raise ValueError(f'{relative}: licence must be {expected}')
        source = path.read_text(encoding='utf-8')
        if '\x00' in source:
            raise ValueError(f'{relative}: binary payload in a text file')
        labels = re.findall(r'SPDX-License-Identifier:\s*([^\s<>]+)', source[:500])
        if path.suffix in CODE | {'.md', '.svg'} and labels != [expected]:
            raise ValueError(f'{relative}: missing or conflicting SPDX header')
        if path.suffix == '.json':
            data = json.loads(source)
            if isinstance(data, dict) and 'license' in data and data['license'] != 'CC0-1.0':
                raise ValueError(f'{relative}: conflicting JSON licence')
        if path.suffix == '.py': imports |= check_python(source, relative, root)
        elif path.suffix == '.gd': resources |= check_gd(source, relative, root, full)
        elif path.suffix == '.svg': check_svg(source, relative)
        counts['software_0bsd' if expected == '0BSD' else 'content_cc0'] += 1
    return {
        'format': 1, 'license': 'CC0-1.0', 'result': 'PASS',
        'scope': 'Declared file licences, reviewed legal texts, static imports and source-only inventory. Not legal clearance or runtime validation.',
        **counts, 'python_modules': sorted(imports), 'godot_project_resources': sorted(resources),
        'bundled_external_implementation_dependencies': [],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    try:
        result = audit(args.root)
    except (OSError, ValueError, TypeError, KeyError, SyntaxError, ET.ParseError) as error:
        print(f'FAIL: {error}', file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
