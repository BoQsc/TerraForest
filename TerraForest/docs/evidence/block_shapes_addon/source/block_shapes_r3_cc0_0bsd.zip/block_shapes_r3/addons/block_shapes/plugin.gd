# SPDX-License-Identifier: 0BSD
@tool
extends EditorPlugin

const Library = preload("res://addons/block_shapes/library.gd")
const Exporter = preload("res://addons/block_shapes/exporter.gd")
const World = preload("res://addons/block_shapes/world.gd")
var _dock: VBoxContainer
var _status: Label
var _dialog: EditorFileDialog
var _exporter: EditorExportPlugin

func _enter_tree() -> void:
	_exporter = Exporter.new()
	add_export_plugin(_exporter)
	add_custom_type("BlockShapeWorld", "Node3D", World, null)
	_dock = VBoxContainer.new()
	_dock.name = "Block Shapes"
	var title := Label.new()
	title.text = "BLOCK SHAPES / r2\n224 meshes · 18 families\nCode: 0BSD / geometry: CC0"
	_dock.add_child(title)
	var info := Label.new()
	info.text = "Create a MeshLibrary for Godot's\nGridMap editor, or attach world.gd\nfor runtime chunked construction."
	_dock.add_child(info)
	var export_button := Button.new()
	export_button.text = "Export MeshLibrary…"
	export_button.pressed.connect(_choose_path)
	_dock.add_child(export_button)
	_status = Label.new()
	_status.text = "Use GridMap cell size: 1, 1, 1."
	_dock.add_child(_status)
	_dialog = EditorFileDialog.new()
	_dialog.file_mode = EditorFileDialog.FILE_MODE_SAVE_FILE
	_dialog.access = EditorFileDialog.ACCESS_RESOURCES
	_dialog.add_filter("*.tres", "Godot MeshLibrary")
	_dialog.current_file = "block_shapes.tres"
	_dialog.file_selected.connect(_export_library)
	_dock.add_child(_dialog)
	add_control_to_dock(EditorPlugin.DOCK_SLOT_RIGHT_UL, _dock)

func _choose_path() -> void:
	_dialog.popup_centered_ratio(0.6)

func _export_library(path: String) -> void:
	var library = Library.new()
	var result: Error = ResourceSaver.save(library.create_mesh_library(), path)
	_status.text = "Saved: " + path if result == OK else "Save failed: " + error_string(result)
	if result == OK:
		get_editor_interface().get_resource_filesystem().scan()

func _exit_tree() -> void:
	if _exporter != null:
		remove_export_plugin(_exporter)
		_exporter = null
	remove_custom_type("BlockShapeWorld")
	if _dock != null:
		remove_control_from_docks(_dock)
		_dock.queue_free()
