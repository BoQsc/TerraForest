<!-- SPDX-License-Identifier: CC0-1.0 -->
# Block Shapes r3 — origin and work record

Date: 2026-10-25. AI-assisted development in the requesting user's conversation.
Release licences: 0BSD implementation, CC0-1.0 data/assets/project content.

## Actual inputs

The working baseline was the supplied `block_shapes_r2_cc0_0bsd.zip`.
Its file manifests and all 47 prior Python tests passed before this revision.
`ORIGIN.json` retains earlier records and records the exact r2 archive/source
hashes. Those earlier declarations are preserved as historical records, not
retroactively converted into an independent authorship attestation.

The r2 numerical recipes and builder generate the 224 meshes. r3 leaves that
geometry path and the core GDScript implementation unchanged. No 7DTD asset,
external shape catalogue, texture, icon, font or third-party addon source was
introduced during this revision. The source was inspected, not merely counted.
Earlier discussion of other voxel systems is disclosed in the retained record.

## New work in r3

The conversation assistant authored `audit.py`, `tests/license_test.py` and
`tests/gate_test.py`, and rewrote `tools/check.py`. These changes enforce the
requested licence/dependency policy and distinguish missing Godot tests from
successful full automated validation. New documentation states the release
licences directly and separates licensing scope from runtime test status.
All new implementation is released under 0BSD; new documentation/report data
under CC0-1.0. No outside implementation was imported for these changes.

The dependency checker uses standard-library Python AST/XML parsing and a
small original GDScript lexical scanner. It does not import a third-party
licence scanner. Its limits are stated: it recognizes this project's admitted
file/import policy, not arbitrary copyright provenance or hidden semantic
behaviour. Manifests and reports are unsigned integrity records.

## References and host tools

Official 0BSD and CC0 terms were consulted; the supplied standard legal texts
were retained byte-for-byte. Godot's official CLI/API documentation was used
for command contracts, not copied example implementation code. The reference
URLs and purposes are recorded in `ORIGIN.json`.

A Godot 4 executable was not installed in checked local locations. Official
download attempts failed (network/download access unavailable); no engine or
export template was obtained or bundled. Python checks ran locally. The full
runner deliberately returns non-success when Godot cannot run.

## What this record means

It supplies traceable project inputs, per-file scope, a self-contained numeric
build and tests of the declared dependency/licence policy. It does not claim
formal clean-room separation, an independent copyright clearance, a human
signature or an impossible guarantee that no third-party claim can be made.
This qualification does not change or postpone the stated 0BSD/CC0 licences.
