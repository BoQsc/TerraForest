<!-- SPDX-License-Identifier: CC0-1.0 -->
# Origin record

See `addons/block_shapes/ORIGIN.md` and `ORIGIN.json` for the actual lineage,
input hashes, r3 authoring work and verification boundaries.
