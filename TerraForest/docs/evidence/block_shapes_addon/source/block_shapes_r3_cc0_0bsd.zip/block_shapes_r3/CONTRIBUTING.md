<!-- SPDX-License-Identifier: CC0-1.0 -->
# Contribution intake policy

These rules govern what project maintainers accept; they do not add conditions
to downstream 0BSD/CC0 use.

Prefer a numerical architectural requirement and a whitelisted primitive
recipe over an imported mesh. Keep requirements, mathematical construction,
source history, external references and test changes together.

Do not import proprietary game meshes, extracted XML shape catalogues, traced
artwork, logos, icons, decompiled implementation or another addon's code and
relabel it 0BSD/CC0. Different permissive licences are not automatically 0BSD.
An external file advertised as CC0/0BSD is not admitted solely on that label:
record its actual source, applicable terms and the supplier's authority.
Unknown or disputed origins stay outside the distributable package until
resolved. Never hide a questionable origin by rewriting or regenerating it.

A human contributor should record their real identity or a chosen attributable
handle, the exact contribution, prior sources/rights and their authority to
release software under 0BSD and content under CC0-1.0. AI assistance should be
disclosed rather than disguised as a signed human attestation. No declaration
has been pre-signed or invented for the requesting user in this package.

For each change: update the recipe/implementation, rerun relevant tests, record
the actual origin/change in the full project's provenance/files.json, and
explicitly regenerate the inventories. A hash refresh is not legal approval.
Unknown files must not be silently added by the verifier.

The existing licence permissions do not require a user to sign a contribution
form before using the package. Consult qualified counsel when an actual
rights concern or a release requiring independent clearance warrants it.
