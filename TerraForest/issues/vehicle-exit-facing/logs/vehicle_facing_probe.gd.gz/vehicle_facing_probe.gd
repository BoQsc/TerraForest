extends "res://tests/world_vehicle.gd"
func run()->void:
 var world:=Fixture.new();root.add_child(world)
 world.add_child(world.terrain);world.add_child(world.structures);world.add_child(world.player);world.player.add_child(world.camera)
 world.camera.position=Vector3(0,1.68,0);world.camera.rotation.x=-.1
 var floor:=StaticBody3D.new();var collision:=CollisionShape3D.new();var box:=BoxShape3D.new();box.size=Vector3(60,1,60)
 collision.shape=box;floor.position=Vector3(400,179.5,400);floor.add_child(collision);world.add_child(floor)
 var session=load("res://addons/vehicle_runtime/world_vehicle.gd").new();world.add_child(session)
 var persistence=load("res://addons/world_runtime/world_persistence.gd").new();session.prepare(world,persistence)
 session._install_vehicle(world,Transform3D(Basis(Vector3.UP,PI),Vector3(400,180.85,400)))
 var rows:Array=[]
 for turn in [0.0,90.0,180.0]:
  session.car.freeze=true;session.car.set_physics_process(false);session.car.rotation.y=PI
  world.player.rotation.y=0;world.player.position=session.car.position+Vector3.RIGHT*2.8
  await physics_frame;await physics_frame
  if not session.enter(world):print("FAIL facing fixture entry");world.free();quit(1);return
  session.car.freeze=true;session.car.set_physics_process(false)
  session.car.rotation.y=PI+deg_to_rad(turn)
  await physics_frame;await physics_frame
  for tick in 120:session._camera_follow.update(session.car,world.camera,1.0/60)
  var front:Vector3=session.car.global_basis.z;front.y=0;front=front.normalized()
  var message:String=session.exit_vehicle(world)
  if not message.begins_with("On foot"):print("FAIL facing fixture exit ",message);world.free();quit(1);return
  var facing:Vector3=-world.player.global_basis.z;facing.y=0;facing=facing.normalized()
  var view:Vector3=-world.camera.global_basis.z;view.y=0;view=view.normalized()
  var row:={"vehicle_turn_degrees":turn,"player_vehicle_angle_degrees":rad_to_deg(acos(clampf(front.dot(facing),-1,1))),"view_vehicle_angle_degrees":rad_to_deg(acos(clampf(front.dot(view),-1,1))),"player_facing":facing,"car_front":front}
  rows.append(row);print("EXIT_FACING ",row)
 var file:=FileAccess.open("res://reports/vehicle_facing_probe.json",FileAccess.WRITE);file.store_string(JSON.stringify(rows,"  "));file.close()
 world.free();await process_frame;print("PASS vehicle facing observed");quit(0)
